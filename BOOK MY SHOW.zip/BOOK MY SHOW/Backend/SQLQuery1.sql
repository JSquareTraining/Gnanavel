use smkg
create table ticket_booking(ticket_id int identity,usname nvarchar(50),TheatreName nvarchar(30),Timing nvarchar(20),sheet nvarchar(30),bo_date date)
select * from ticket_booking
create table theater(theatre_name nvarchar(30),movie_date date,movie nvarchar(30),timing nvarchar(20))
insert into theater values('KG','2015-01-07','I')
insert into theater values('KG','2015-01-20','Yennaiarindhal')
insert into theater values('senthil','2015-01-07','I')
select * from theater
alter table theater drop column regno
alter table theater add  city nvarchar(30)
alter table theater add constraint df primary key(regno)
alter table theater add acno numeric(20)
select * from ticket_booking
alter table registration1 add creditcard numeric(16)
select * from registration1
delete from registration1 where creditcard is  null
truncate table ticket_booking
