﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace regiandlogin
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if(!IsPostBack)
            {
            lblerror.Visible = false;
            txtpassword.Text = "";
            txtusern.Text = "";
            }
        }

        protected void Login1_Authenticate(object sender, AuthenticateEventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            
        }
        dataacesslayer dacc = new dataacesslayer();
        dataacesslayer.regi strreg = new dataacesslayer.regi();
        public void logi()
        {
            strreg.username = txtusern.Text;
            strreg.passwor = txtpassword.Text;
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            lblerror.Visible = true;
            logi();
            if (txtusern.Text != "" & txtpassword.Text != "")
            {
                object i = dacc.log(strreg);
                int k = Convert.ToInt32(i);
                if (k >= 1)
                {
                    string person=txtusern.Text;
                    txtusern.Text = "";
                    txtpassword.Text = "";
                    Response.Redirect("booking.aspx?Username=" + person);
                    
                }
                else
                {
                    lblerror.Text = "Invalid User";
                }
            }
            else
            {
                lblerror.Text = "(*)Fields are Required";
            }
        }
    }
}