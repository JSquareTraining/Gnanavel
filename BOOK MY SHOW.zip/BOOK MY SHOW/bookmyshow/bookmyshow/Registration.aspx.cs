﻿using System;
using System.Drawing;

namespace regiandlogin
{
    public partial class Registration : System.Web.UI.Page
    {
        dataacesslayer dac = new dataacesslayer();
        dataacesslayer.regi structreg = new dataacesslayer.regi();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                lblstatus.Visible = false;
       
            }
        }
        public void valupass2struct()
    {
        structreg.username = txtusername.Text;
        structreg.passwor = txtpass.Text;
        structreg.firstname = txtfirst.Text;
        structreg.middlename = txtmidd.Text;
        structreg.lastname = txtlast.Text;
        structreg.phno = txtphno.Text;
        structreg.pincode = txtpin.Text;
        structreg.city = ddcity.Text;
        structreg.dob = calen1.SelectedDate.ToShortDateString();
        structreg.address = txtaddress.Text;
        structreg.email = txtemail.Text;
        structreg.surename = txtsure.Text;
        structreg.creditcard = txtcredit.Text;
            if(rdfemale.Checked==true)
            {
                structreg.gender = rdfemale.Text;
            }
            else if (rdmale.Checked == true)
            {
                structreg.gender = rdmale.Text;
            }
    }
        protected void TextBox7_TextChanged(object sender, EventArgs e)
        {
           
            
        }

        protected void TextBox9_TextChanged(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                lblstatus.Visible = true;
                valupass2struct();
                if (txtusername.Text != "" & txtpass.Text != "" & txtfirst.Text != "" & txtlast.Text != "" & txtphno.Text != "" & txtpin.Text != "" & txtsure.Text != "" & txtaddress.Text != "" & txtdob.Text != "" & txtemail.Text != "" & txtcredit.Text!="" )
                {
                    if (txtpass.Text == txtrepass.Text)
                    {
                        int i = dac.reg(structreg);
                        if (i >= 1)
                        {
                            clr();
                            lblstatus.Visible = true;
                            lblstatus.ForeColor = Color.Green;
                            lblstatus.Text = "Registered";
                        }
                        else
                        {
                            lblstatus.Text = "Failed";
                        }
                    }
                    else
                    {
                        lblstatus.Text = "Miss-Match Password";
                    }
                }
                else
                {
                    lblstatus.Text = "(*)fields are Required";
                }
            }
            catch
            {
                lblstatus.Visible = true;
                lblstatus.Text = "Already Existed Username";
            }
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            
            txtdob.Text = calen1.SelectedDate.ToShortDateString();
        }

        protected void LinkButton1_Click(object sender, EventArgs e)
        {
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            clr();
        }
        public void clr()
        {
            txtemail.Text = "";
            txtfirst.Text = "";
            txtlast.Text = "";
            txtusername.Text = "";
            txtsure.Text = "";
            txtpin.Text = "";
            txtrepass.Text = "";
            txtsure.Text = "";
            txtmidd.Text = "";
            lblstatus.Visible = false;
            txtdob.Text = "";
            txtaddress.Text = "";
            txtpass.Text = "";
            txtphno.Text = "";
        }
    }
}