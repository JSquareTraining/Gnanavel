﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace bookmyshow
{
    public partial class book : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void DropDownList2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (DropDownList2.Text == "Ajith")
            {
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("Yennai Arinthal");
            }
            else if (DropDownList2.Text == "Vijay")
            {
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("Kathi");
            }
            else if (DropDownList2.Text == "Rajini")
            {
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("Linga");
            }
            else if (DropDownList2.Text == "Amirkhan")
            {
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("pk");
            }
            else if (DropDownList2.Text == "Others")
            {
                DropDownList3.Items.Clear();
                DropDownList3.Items.Add("Click Movie Tagto know");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("Login.aspx");
        }
    }
}