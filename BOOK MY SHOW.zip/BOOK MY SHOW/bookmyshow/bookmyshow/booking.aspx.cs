﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Drawing;
using System.Data.SqlClient;
using regiandlogin;

namespace bookmyshow
{
    public partial class booking : System.Web.UI.Page
    {
        public string sheetno;
        public int cou = 0;
        public int val;
        dataacesslayer dacc = new dataacesslayer();
        dataacesslayer.book db = new dataacesslayer.book();
        protected void Page_Load(object sender, EventArgs e)
        {
          
            if (!IsPostBack)
            {
                if (Request.QueryString["Username"].ToString() != "")
                {
                     lblusername.Text = Request.QueryString["Username"].ToString();                    
                }

                lblsheet.Visible = false;
                lblsheets.Visible = false;
                btnpayment.Visible = false;
                SqlDataReader dr;
                dr = dacc.nameread();
                DropDownList1.Items.Clear();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        DropDownList1.Items.Add(dr[0].ToString());
                    }
                }
                
            }
            
        }
   
        
        protected void ImageButton33_Click(object sender, ImageClickEventArgs e)
        {

        }
        public void bookings()
        {
            db.moviename = DropDownList2.Text;
            db.qty = lblsheet.Text;
            db.theatername = DropDownList1.Text;
            db.username = lblusername.Text;
            db.timing = DropDownList3.Text;
            db.booking_date = txtdate.Text;

        }
        
        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            val = (Convert.ToInt32(Label5.Text) + 1);
            Label5.Text = val.ToString();
            ImageButton ib = (ImageButton)sender;
            ib.ImageUrl = "";
            int val1=Convert.ToInt32(dtpcount.Text)+1;
            if (val < val1)
            {
                ib.BackColor = Color.Red;
                lblsheet.Text = (ib.AlternateText + "," + lblsheet.Text).ToString();
                if (ib.TabIndex.ToString() == ib.AlternateText)
                {
                    ib.Enabled = false;
                }
                btnpayment.Visible = true;
                lblsheets.Visible = true;
                lblsheet.Visible = true;
                lblamount.Text = (Convert.ToDouble(val) * 120).ToString();
            }
            else
            {
                ib.ImageUrl = "~/images/sheet.jpg";
                ib.Enabled = false;
                
            }
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
        }

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {
             SqlDataReader dr;
            dr = dacc.dateread(DropDownList1.SelectedItem.Text);
            DropDownList2.Items.Clear();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    DropDownList2.Items.Add(dr[0].ToString());
                }
            }
            for (int i = 1; i <= 60; i++)
            {
                dtpcount.Items.Add(i.ToString());
            }
        }

        protected void btnpayment_Click(object sender, EventArgs e)
        {
            bookings();
            dacc.payment(db);
            btnpayment.Visible = false;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            txtdate.Text = Calendar1.SelectedDate.Date.ToShortDateString();
        }
        public string sh;
        protected void txtdate_TextChanged(object sender, EventArgs e)
        {
            if (txtdate.Text!="")
            {
                bookings();
                SqlDataReader dr;
                dr = dacc.booking_date(db);
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        sh = dr[0].ToString();
                    }
                }
            }
            
        }

        protected void Button1_Click1(object sender, EventArgs e)
        {
            Response.Redirect("ticketprint.aspx?user="+lblusername.Text);
        }
    }
}