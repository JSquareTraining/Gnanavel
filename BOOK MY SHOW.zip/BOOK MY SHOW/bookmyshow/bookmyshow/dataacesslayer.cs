﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace regiandlogin
{
    public class dataacesslayer
    {
        logicallayer lo = new logicallayer();
        public string str;
        public struct regi
        {
            public string username;
            public string passwor;
            public string  firstname;
            public string middlename;
            public string lastname;
            public string surename;
            public string dob;
            public string gender;
            public string email;
            public string phno;
            public string address;
            public string city;
            public string pincode;
            public string creditcard;
        }
        public struct book
        {
            public string username;
            public string theatername;
            public string moviename;
            public string timing;
            public string qty;
            public string booking_date;
        }
        public struct sear
        {
            public string phone_number;
            public string password;
        }
        public struct theatrereg
        {
            public string theatname;
            public string moviedate;
            public string movie;
            public string acno;
            public string regno;
            public string city;
        }
        public int reg(regi r)
        {
            str = "insert into registration1 (username,passwor,firstname,middlename,lastname,surename,dob,gender,email,phno,addres,city,pincode,creditcard)values(" + "'" + r.username + "'" + "," + "'" + r.passwor + "'" + "," + "'" + r.firstname + "'" + "," + "'" + r.middlename + "'" + "," + "'" + r.lastname + "'" + "," + "'" + r.surename + "'" + "," + "'" + r.dob + "'" + "," + "'" + r.gender + "'" + "," + "'" + r.email + "'" + "," + "'" + r.phno + "'" + "," + "'" + r.address + "'" + "," + "'" + r.city + "'" + "," + "'" + r.pincode + "'"+","+"'"+r.creditcard +"'"+ ")";
            lo.qry = str;
         return lo.executeregi();
        }
        public object log(regi r)
        {
            str = "Select count(*) from registration1 where username=" + "'" + r.username + "'" + " and passwor=" + "'" + r.passwor + "'";
            lo.qry = str;
            return lo.Execute_Slr();
        }
        public DataSet fill()
        {
            str = "select * from registration1";
            lo.qry = str;
            return lo.Adaptor();
        }
        public DataSet search_phfill(sear s)
        {
            str = "select * from registration1 where phno=" + "'" + s.phone_number + "'";
            lo.qry = str;
            return lo.Adaptor();
        }
        public DataSet search_passfill(sear s)
        {
            str = "select * from registration1 where passwor=" + "'" + s.password + "'";
            lo.qry = str;
            return lo.Adaptor();
        }
        public DataSet namebind()
        {
            lo.qry = "select * from theater";
            return lo.Adaptor();
        }
        public SqlDataReader nameread()
        {
            lo.qry = "select theatre_name from theater";
            return lo.Reader();
        }
        public SqlDataReader dateread(string name)
        {
            lo.qry = "select movie from theater where theatre_name=" + "'" + name + "'";
            return lo.Reader();
        }
        public int payment(book b)
        {
            lo.qry = "insert into ticket_booking(usname,TheatreName,Timing,sheet,bo_date)values(" + "'" + b.username + "'" + "," + "'" + b.theatername + "'" + "," + "'" + b.timing + "'" + "," + "'" + b.qty + "'" + "," + "'" + b.booking_date + "'" + ")";
            return lo.executeregi();
        }
        public SqlDataReader booking_date(book b)
        {
            lo.qry = "select sheet from ticket_booking where bo_date=" + "'" + b.booking_date + "'";
            return lo.Reader();
        }
        public DataSet ticketview(string b)
        {
            lo.qry = "select ticket_id as TicketNo,TheatreName,Timing as ShowTime,sheet as SheetNo,bo_date as ShowDate from ticket_booking where usname=" + "'" + b + "'";
            return lo.Adaptor();
        }
        public DataSet ticketprint(string b)
        {
            lo.qry = "select ticket_id as TicketNo,TheatreName,Timing as ShowTime,sheet as SheetNo,bo_date as ShowDate from ticket_booking where ticket_id=" + "'" + b + "'";
            return lo.Adaptor();
        }
        public int theatreregnew(theatrereg tr)
        {
            lo.qry = "insert into theater(theatre_name,movie_date,movie,acno,regno,city)values(" + "'" + tr.theatname + "'" + "," + "'" + tr.moviedate + "'" + "," + "'" + tr.movie + "'" + "," + "'" + tr.acno + "'" + "," + "'" + tr.regno + "'" + "," + "'" + tr.city + "'" + ")";
            return lo.executeregi();
        }
        public int thdelete(theatrereg tr)
        {
            lo.qry = "delete from theater where regno=" + "'" + tr.regno + "'";
            return lo.executeregi();
        }
    }
}