﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data.SqlClient;
using System.Data;

namespace regiandlogin
{
    
    public class logicallayer
    {
         SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=smkg;Data Source=smkg");
               
        public string query="";
        public string qry
        {
            get
            {
                return query;
            }
            set
            {
                query = value;
            }
        }
        public int executeregi()
        {
            con.Close();
            con.Open();
                SqlCommand cmd = new SqlCommand(query, con);
                int i = cmd.ExecuteNonQuery();
                con.Close();
                return i;   
        }
        public object Execute_Slr()
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            object i = cmd.ExecuteScalar();
            con.Close();
            return i;
        }
        public DataSet Adaptor()
        {
            con.Close();
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(query, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "lance");
            con.Close();
            return ds;
        }
        public SqlDataReader Reader()
        {
            con.Close();
            con.Open();
            SqlCommand cmd = new SqlCommand(query, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            //con.Close();
            return dr;
        }
    }
}