﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using regiandlogin;

namespace bookmyshow
{
    public partial class theatreregistration : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                lblstatus.Visible = false;
            }
        }
        dataacesslayer dacc = new dataacesslayer();
        dataacesslayer.theatrereg dt = new dataacesslayer.theatrereg();

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            //txtdate.Text = calen1.SelectedDate.ToShortDateString();
        }
        public void val()
        {
            dt.acno = txtbankac.Text;
            dt.city = dtpcity.Text;
            dt.movie = txtmovie.Text;
            dt.moviedate = txtdate.Text;
            dt.theatname = txttheatername.Text;
            dt.regno = txtregno.Text;
            
        }

        protected void Calendar1_SelectionChanged1(object sender, EventArgs e)
        {
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            lblstatus.Visible = true;
            if (txtbankac.Text != "" & txtmovie.Text != "" & txtregno.Text != "" & txttheatername.Text != "" & txtdate.Text != "" & dtpcity.Text != "")
            {
                val();
                dacc.theatreregnew(dt);
                lblstatus.Text = "Registered";
                clr();
            }
            else
            {
                lblstatus.Text = "(*)All fields are required";
            }
        }
        public void clr()
    {
        txtregno.Text = "";
        txttheatername.Text = "";
        txtmovie.Text = "";
        txtdate.Text = "";
        txtbankac.Text = "";
    }

        protected void btndelete_Click(object sender, EventArgs e)
        {
            lblstatus.Visible = true;
            val();
            if (txtregno.Text != "")
            {
                try
                {
                    dacc.thdelete(dt);
                    lblstatus.Text = "Deleted";
                    txtregno.Text = "";
                }
                catch (Exception ex)
                {
                    lblstatus.Text = ex.ToString();
                }

            }
            else
            {
                lblstatus.Text = "Regno Shoud not be empty";
            }
        }
    }
}