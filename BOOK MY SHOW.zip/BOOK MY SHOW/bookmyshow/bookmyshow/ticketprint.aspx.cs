﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using regiandlogin;

namespace bookmyshow
{
    public partial class ticketprint : System.Web.UI.Page
    {
        dataacesslayer dac = new dataacesslayer();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Request.QueryString["user"].ToString() != "")
                {
                    lbluser.Text = Request.QueryString["user"].ToString();
                       DataSet ds = new DataSet();
                     ds = dac.ticketview(lbluser.Text);
                    GridView1.DataSource = ds;
                    GridView1.DataBind();
                }
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            DataSet ds = new DataSet();
            ds = dac.ticketprint(TextBox1.Text);
            GridView1.DataSource = ds;
            GridView1.DataBind();
        }
    }
}