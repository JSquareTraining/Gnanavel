﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;

namespace Diary
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Registration r = new Registration();
            r.ShowDialog();
        }
        Properties.Settings ps = new Properties.Settings();
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            
            string path = @"D:\" + txtfamily.Text + @"\" + txtname.Text + @"\" + txtname.Text + ".txt";
            if (File.Exists(path))
            {
                string s = File.ReadAllText(path);
                string []s1 = s.Split(',');
                if (txtpass.Text == s1[2])
                {
                    ps.familyname = txtfamily.Text;
                    ps.username = txtname.Text;
                    ps.Save();
                    txtpass.Text = "";
                    txtname.Text = "";
                    txtfamily.Text = "";

                    diary d = new diary();
                    d.ShowDialog();
                }
                else
                {
                    lblstatus.Text = "Invalid user";
                    txtpass.Text = "";
                    txtname.Text = "";
                    txtfamily.Text = "";
                }

            }
            else
            {
                lblstatus.Text = "Invalid user";
                txtpass.Text = "";
                txtname.Text = "";
                txtfamily.Text = "";
            }

        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            txtpass.Text = "";
            txtname.Text = "";
            txtfamily.Text = "";
        }
    }
}
