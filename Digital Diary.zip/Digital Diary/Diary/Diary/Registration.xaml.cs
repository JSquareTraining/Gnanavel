﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Diary
{
    /// <summary>
    /// Interaction logic for Registration.xaml
    /// </summary>
    public partial class Registration : Window
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string path=@"D:\" + txtfamilyname.Text + @"\" + txtusername.Text+ @"\"+ txtusername.Text +".txt";
            
            if (File.Exists(path))
            {
                lblstatus.Text = "This Family and Username Already Exists";
            }
            else
            {
                string writing=txtfamilyname.Text +","+txtusername.Text+","+ txtpassword.Text+","+ txemail.Text;
                if(Directory.Exists(@"D:\" + txtfamilyname.Text))
                {
                    if (Directory.Exists(@"D:\" + txtfamilyname.Text + @"\" + txtusername.Text))
                    {
                        lblstatus.Text = "This Username Already Exists";                      
                    }
                    else
                    {
                        if (txtpassword.Text == txtrepassw.Text)
                        {
                            Directory.CreateDirectory(@"D:\" + txtfamilyname.Text + @"\" + txtusername.Text);
                            lblstatus.Text = "you are added to this family";
                            File.WriteAllText(path, writing);
                            clr();
                        }
                        else
                        {
                            lblstatus.Text = "Your Password Doesn't Match";
                        }
                    }
                }
                else
                {
                    if (txtpassword.Text == txtrepassw.Text)
                    {
                        Directory.CreateDirectory(@"D:\" + txtfamilyname.Text + @"\" + txtusername.Text);
                        File.WriteAllText(path, writing);
                        lblstatus.Text = "Registered";
                        clr();
                    }
                    else
                    {
                        lblstatus.Text = "Your Password Doesn't Match";
                    }
                }
            }

        }
        public void clr()
        {
            txtusername.Text = "";
            txtpassword.Text = "";
            txtrepassw.Text = "";
            txtfamilyname.Text = "";
            txemail.Text = "";
        }
    }
}
