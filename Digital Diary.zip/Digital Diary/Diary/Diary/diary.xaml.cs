﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;

namespace Diary
{
    /// <summary>
    /// Interaction logic for diary.xaml
    /// </summary>
    public partial class diary : Window
    {
        public diary()
        {
            InitializeComponent();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            string today = dtpicker.SelectedDate.Value.ToLongDateString();
            string path = @"D:\" + lblfamily.Text + @"\" + lblusname.Text + @"\" + today + ".txt";
            if (File.Exists(path))
            {
                rchtxt.Text = File.ReadAllText(path);
            }

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            
            string today = DateTime.Now.Date.ToLongDateString();
            string path = @"D:\" + lblfamily.Text + @"\" + lblusname.Text +@"\"+today+".txt";
            if (!File.Exists(path))
            {
                File.WriteAllText(path, rchtxt.Text);
            }
            else
            {
                    string tod = DateTime.Now.Date.ToShortDateString();
                    MessageBox.Show("you can update");
                    File.WriteAllText(path, rchtxt.Text);
            }
        }
        Properties.Settings ps = new Properties.Settings();
        private void Window_Activated_1(object sender, EventArgs e)
        {
            lblfamily.Text = ps.familyname;
            lblusname.Text = ps.username;
            dtpicker.Text = (DateTime.Now.Date).ToString();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            string today = dtpicker.SelectedDate.Value.ToLongDateString();
            string path = @"D:\" + lblfamily.Text + @"\" + lblusname.Text + @"\" + today + ".txt";
            File.Delete(path);
            MessageBox.Show("Deleted");
            rchtxt.Clear();
        }
    }
}
