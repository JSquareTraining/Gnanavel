create database decmonth
use decmonth

select * from teamleader
select * from associate
select * from manager
select batchid,name,designation,dob,emailid,phno,tid,mgrid from associate where batchid='2014201'
select mgrid,name,emailid,phno,passwor from manager where (emailid='smkgnanavel@gmail.com' and phno='')or(emailid='smkgnanavel@gmail.com' and dob= '6/6/1988')or(phno='' and dob='6/6/1988')
select batchid,name,emailid,phno,password,mgrid,tlid from associate where (emailid='smkgnanavel@gmail.com' and '9626838447')or(emailid='smkgnanavel@gmail.com' and '12/12/2014')or(emailid='9626838447' and '12/12/2014')
INSERT INTO manager(name,designation,dob,emailid,phno,city,sstate,country,nationality,aaddress,masterdegree,bachdegree,certification,Exper,passwor)Values('Gnanavel','Software Engineer','6/6/1988 12:00:00 AM','smkgnanavel@gmail.com','9626838447','krishnagiri','Tamilnadu','India','Indian','krishnagiri','MCA','BSC(CS)','DotNet','6','1234')
drop table manager
select * from teamleader
INSERT INTO associate(name,designation,dob,emailid,phno,city,sstate,country,nationality,aaddress,masterdegree,bachdegree,certification,Exper,passwor,tid,mgrid)Values('lance','Software Engineer','5/6/1991 12:00:00 AM','smkgnanavel@gmail.com','9626838447','krishnagiri','Tamilnadu','India','Indian','','MCA','BSC(CS)','DotNet','6','','2014101','2014101')
create table manager
(
mgrid int primary key identity(201401,1),
name nvarchar(50)not null,
designation nvarchar(40)not null,
dob date not null,
emailid nvarchar(40)unique not null,
phno numeric(10)unique not null,
city nvarchar(30)not null,
sstate nvarchar(30) default 'Tamil Nadu',
country nvarchar(30) default 'India',
nationality nvarchar(30) default 'Indian',
aaddress nvarchar(80),
masterdegree nvarchar(20) default 'Nil',
bachdegree nvarchar(20)not null,
certification nvarchar(30)default 'Nil',
Exper int default '0',
passwor nvarchar(15) default 'you123',
)

select * from manager

create table teamleader
(
tid int primary key identity(2014101,1),
name nvarchar(50)not null,
designation nvarchar(30)not null,
dob date not null,
emailid nvarchar(30)unique not null,
phno numeric(10)unique not null,
city nvarchar(30)not null,
sstate nvarchar(30) default 'Tamil Nadu',
country nvarchar(30) default 'India',
nationality nvarchar(30) default 'Indian',
aaddress nvarchar(80),
masterdegree nvarchar(20) default 'Nil',
bachdegree nvarchar(20)not null,
certification nvarchar(30)default 'Nil',
Exper int default '0',
passwor nvarchar(15) default 'you123',
mgrid int foreign key references manager(mgrid)
)
select * from teamleader


create table associate
(
batchid int primary key identity(2014201,1),
name nvarchar(50)not null,
designation nvarchar(30)not null,
dob date not null,
emailid nvarchar(40)unique not null,
phno numeric(10)unique not null,
city nvarchar(30)not null,
sstate nvarchar(30) default 'Tamil Nadu',
country nvarchar(30) default 'India',
nationality nvarchar(30) default 'Indian',
aaddress nvarchar(80),
masterdegree nvarchar(20) default 'Nil',
bachdegree nvarchar(20)not null,
certification nvarchar(30)default 'Nil',
Exper int default '0',
passwor nvarchar(15) default 'you123',
tid int foreign key references teamleader(tid),
mgrid int foreign key references manager(mgrid)
)
SELECT * FROM manager

drop table manager
select * from associate
delete * 

create table admin(batchid numeric(6),passwor nvarchar(15))
insert into admin values('123456','lance')

--all
create table leave(leaveid int identity(1,1),batchid numeric,fromda date unique,todate date unique,totalleave numeric default '10',reason nvarchar(50),tekenleave numeric default '0',availeave as totalleave-tekenleave)

drop table leave
SELECT * FROM leave
select into sss select * from tlfirst
insert into sss  select * from tlfirst --oldtab1 from oldtab2
--SELECT *INTO newtable [IN externaldb] FROM table1;
select sum(nof.noofdays) from mgrapprove as nof inner join tlapprove as tl on tl.batchid=nof.batchid,
select * from mgrsecond
--tl
SELECT * FROM tlfirst
DROP TABLE TLFIRST
create table tlfirst(batchid numeric ,fromda date unique,todate date unique,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)
create table tlapprove(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)
create table tlcancel(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)
select * from timemgr
delete from fnlrecent
delete from tlfirst
delete from tlapprove
delete from tlcancel
delete from mgrapprove
delete from mgrsecond
delete from mgrcancel
delete from leave
delete from timemgr

select * from mgrapprove
select * from tlapprove
select * from leave
select totalleave,tekenleave,availeave from leave where batchid='2014201'
select sum(tekenleave) from leave where batchid='2014201'
insert into mgrcancel select * from mgrsecond mgrid='2014101'
select sum(noofdays) from mgrapprove where batchid='2014101'
select * from mgrapprove
delete from fnlrecent
drop table mgrsecond
--mgr
create table mgrapprove(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)
create table mgrcancel(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)
create table mgrsecond(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)

--final
create table fnlcancel(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)
create table fnlrecent(batchid numeric,fromda date,todate date,reason nvarchar(50),noofdays int,tlid numeric,mgrid numeric)e

select cudate from diary where batchid='2014201' and cudate='12/14/2014'
create table diary(batchid numeric,cudate date,msg nvarchar(100))
ALETER table DIARY modify  COLUMN MSG NVARCHAR(500)
select * from diary
delete diary

update diary set msg='fgfdgFDFSDAFASDFDSFSDFSDFSADFASDFSDFSDFDSFDSFDSFDF' where (batchid='2014201' AND cudate='12/14/2014')
create table sticky(id numeric,remain1 nvarchar(400),remain2 nvarchar(400),remain3 nvarchar(400))

create table timesheet(id numeric,dtime nvarchar(20),rcord nvarchar(100))

select * from associate
delete from sticky
delete from timemgr
select * from timesheet
SELECT *INTO  timemgr FROM timesheet
select * from timemgr
alter table timemgr add batchid numeric
select * from mgrapprove
select * from leave
alter table leave add tlid numeric,mgrid numeric
select * from fnlcancel
insert into tlcancel select * from tlfirst batchid='2014201'

delete from leave
select * from leave
alter table leave alter column fromda unique not null
select * from tlfirst
delete from fnlcancel where batchid='2014101'
create table history(batchid nvarchar(50),rolle nvarchar(55),datee nvarchar(50) ,timee nvarchar(50));
drop table history
select * from history