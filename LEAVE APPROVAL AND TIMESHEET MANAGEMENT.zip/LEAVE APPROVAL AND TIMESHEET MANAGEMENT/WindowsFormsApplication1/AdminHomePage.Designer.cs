﻿namespace WindowsFormsApplication1
{
    partial class AdminHomePage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.associateRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamLeaderRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.managerRegistrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.managerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.teamLeadersToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.associatesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.loginHistoryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.logoutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.menuStrip.SuspendLayout();
            this.statusStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.associateRegistrationToolStripMenuItem,
            this.teamLeaderRegistrationToolStripMenuItem,
            this.managerRegistrationToolStripMenuItem,
            this.reportsToolStripMenuItem,
            this.logoutToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(935, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // associateRegistrationToolStripMenuItem
            // 
            this.associateRegistrationToolStripMenuItem.Name = "associateRegistrationToolStripMenuItem";
            this.associateRegistrationToolStripMenuItem.Size = new System.Drawing.Size(132, 20);
            this.associateRegistrationToolStripMenuItem.Text = "Manager Registration";
            this.associateRegistrationToolStripMenuItem.Click += new System.EventHandler(this.associateRegistrationToolStripMenuItem_Click);
            // 
            // teamLeaderRegistrationToolStripMenuItem
            // 
            this.teamLeaderRegistrationToolStripMenuItem.Name = "teamLeaderRegistrationToolStripMenuItem";
            this.teamLeaderRegistrationToolStripMenuItem.Size = new System.Drawing.Size(153, 20);
            this.teamLeaderRegistrationToolStripMenuItem.Text = "Team Leader Registration";
            this.teamLeaderRegistrationToolStripMenuItem.Click += new System.EventHandler(this.teamLeaderRegistrationToolStripMenuItem_Click);
            // 
            // managerRegistrationToolStripMenuItem
            // 
            this.managerRegistrationToolStripMenuItem.Name = "managerRegistrationToolStripMenuItem";
            this.managerRegistrationToolStripMenuItem.Size = new System.Drawing.Size(135, 20);
            this.managerRegistrationToolStripMenuItem.Text = "Associate Registration";
            this.managerRegistrationToolStripMenuItem.Click += new System.EventHandler(this.managerRegistrationToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.managerToolStripMenuItem,
            this.teamLeadersToolStripMenuItem,
            this.associatesToolStripMenuItem,
            this.loginHistoryToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // managerToolStripMenuItem
            // 
            this.managerToolStripMenuItem.Name = "managerToolStripMenuItem";
            this.managerToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.managerToolStripMenuItem.Text = "Managers";
            this.managerToolStripMenuItem.Click += new System.EventHandler(this.managerToolStripMenuItem_Click);
            // 
            // teamLeadersToolStripMenuItem
            // 
            this.teamLeadersToolStripMenuItem.Name = "teamLeadersToolStripMenuItem";
            this.teamLeadersToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.teamLeadersToolStripMenuItem.Text = "TeamLeaders";
            this.teamLeadersToolStripMenuItem.Click += new System.EventHandler(this.teamLeadersToolStripMenuItem_Click);
            // 
            // associatesToolStripMenuItem
            // 
            this.associatesToolStripMenuItem.Name = "associatesToolStripMenuItem";
            this.associatesToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.associatesToolStripMenuItem.Text = "Associates";
            this.associatesToolStripMenuItem.Click += new System.EventHandler(this.associatesToolStripMenuItem_Click);
            // 
            // loginHistoryToolStripMenuItem
            // 
            this.loginHistoryToolStripMenuItem.Name = "loginHistoryToolStripMenuItem";
            this.loginHistoryToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.loginHistoryToolStripMenuItem.Text = "Login History";
            this.loginHistoryToolStripMenuItem.Click += new System.EventHandler(this.loginHistoryToolStripMenuItem_Click);
            // 
            // logoutToolStripMenuItem
            // 
            this.logoutToolStripMenuItem.Name = "logoutToolStripMenuItem";
            this.logoutToolStripMenuItem.Size = new System.Drawing.Size(57, 20);
            this.logoutToolStripMenuItem.Text = "Logout";
            this.logoutToolStripMenuItem.Click += new System.EventHandler(this.logoutToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 411);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(935, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // AdminHomePage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.BackgroundImage = global::WindowsFormsApplication1.Properties.Resources.Hw1__42_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(935, 433);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "AdminHomePage";
            this.Text = "AdminHomePage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem associateRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamLeaderRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem managerRegistrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem logoutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem managerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem teamLeadersToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem associatesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem loginHistoryToolStripMenuItem;
    }
}



