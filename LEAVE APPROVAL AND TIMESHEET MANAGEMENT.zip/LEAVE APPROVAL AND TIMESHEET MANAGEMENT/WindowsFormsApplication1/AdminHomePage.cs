﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class AdminHomePage : Form
    {
       

        public AdminHomePage()
        {
            InitializeComponent();
        }
        public static int i = 0;
        private void logoutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            i = 3;
            this.Close();
        }

        private void associateRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Manager_Registration mgr = new Manager_Registration();
            mgr.ShowDialog();
            
        }

        private void teamLeaderRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            TeamleaderRegistration tl = new TeamleaderRegistration();
            tl.ShowDialog();
        }

        private void managerRegistrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AssociateRegistration ar = new AssociateRegistration();
            ar.ShowDialog();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void managerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            mgrreport mr = new mgrreport();
            mr.ShowDialog();
        }

        private void teamLeadersToolStripMenuItem_Click(object sender, EventArgs e)
        {
            teamlead tler = new teamlead();
            tler.ShowDialog();
        }

        private void associatesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            associ ai = new associ();
            ai.ShowDialog();
        }

        private void loginHistoryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            loginhistory lh = new loginhistory();
            lh.ShowDialog();
        }
    }
}
