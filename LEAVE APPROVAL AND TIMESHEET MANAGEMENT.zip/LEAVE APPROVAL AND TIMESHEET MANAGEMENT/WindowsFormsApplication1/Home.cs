﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace WindowsFormsApplication1
{
    public partial class Home : Form
    {
       

        public Home()
        {
            InitializeComponent();
        }
        public static int j = 0;
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlCommand cmd;
        SqlDataReader dr;
       // DataSet ds;
        SqlDataAdapter da;
        public string k, today,ex;
        LeaveApply le = new LeaveApply();
        public int s;
        Properties.Settings ps = new Properties.Settings();
        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }
        public void lea()
        {
            leaover();
            con.Open();
            cmd = new SqlCommand("select totalleave,tekenleave,availeave from leave where batchid=" + "'" + ps.batchid + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    lbltotal.Text = dr[0].ToString();
                    lbltaken.Text = dr[1].ToString();
                    lblavail.Text = dr[2].ToString();
                }
            }
            else
            {
                con.Close();
                con.Open();
                lbltotal.Text = "10".ToString();
                lbltaken.Text = Convert.ToInt32(s).ToString();
                lblavail.Text = (Convert.ToInt32(lbltotal.Text) - Convert.ToInt32(lbltaken.Text)).ToString();
                con.Close();
                
            }
            con.Close();
        }
        public void stick()
        {
            con.Open();
            cmd = new SqlCommand("select remain1,remain2,remain3 from sticky where id=" + "'" + ps.batchid + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    richTextBox1.Text = dr[0].ToString();
                    richTextBox2.Text = dr[1].ToString();
                    richTextBox3.Text = dr[2].ToString();
                }
            }
            else
            {
            }
            con.Close();
        }
        public void leaover()
        {
            con.Open();
            cmd = new SqlCommand("select sum(noofdays) from mgrapprove where batchid=" + "'" + ps.batchid + "'", con);
            dr = cmd.ExecuteReader();
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    string c = dr[0].ToString();
                    if (c == "")
                    {
                        s = 0;
                    }
                    else
                    {
                        s = Convert.ToInt32(c);
                    }
                }
                con.Close();
            }
            else
            {
                s = 0;
            }
            con.Close();
            
        }
        private void Home_Load(object sender, EventArgs e)
        {
            pict();
            txtpictpath.Hide();
            lblstatus.Hide();
            fil();
            stick();
            lea();
            label4.Hide();
            con.Open();
            if (ps.role == "ASSOCIATE")
            {
                btnleave.Hide();
                btnknow.Visible = true;
                btntime.Visible = false;
                cmd = new SqlCommand("select batchid,name,designation,dob,emailid,phno,tid,mgrid from associate where batchid=" + "'" + ps.batchid + "'", con);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        lblbatch.Text = dr[0].ToString();
                        lblname.Text = dr[1].ToString();
                        lbldest.Text = dr[2].ToString();
                        lbldob.Text = dr[3].ToString();
                        lblemail.Text = dr[4].ToString();
                        lblphno.Text = dr[5].ToString();
                        lbltl.Text = dr[6].ToString();
                        lblmgr.Text = dr[7].ToString();
                    }
                }
                con.Close();

            }
            else if (ps.role == "TEAMLEADER")
            {
                btnleave.Show();
                btntime.Show();
                cmd = new SqlCommand("select tid,name,designation,dob,emailid,phno,mgrid from teamleader where tid=" + "'" + ps.batchid + "'", con);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        lblbatch.Text = dr[0].ToString();
                        lblname.Text = dr[1].ToString();
                        lbldest.Text = dr[2].ToString();
                        lbldob.Text = dr[3].ToString();
                        lblemail.Text = dr[4].ToString();
                        lblphno.Text = dr[5].ToString();
                        lblmgr.Text = dr[6].ToString();
                    }
                }
                ps.mgrtime = lblmgr.Text;
                ps.Save();
                con.Close();
            }
            else if (ps.role == "MANAGER")
            {
                btnknow.Visible = true;
                btnleave.Show();
                cmd = new SqlCommand("select mgrid,name,designation,dob,emailid,phno from manager where mgrid=" + "'" + ps.batchid + "'", con);
                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        lblbatch.Text = dr[0].ToString();
                        lblname.Text = dr[1].ToString();
                        lbldest.Text = dr[2].ToString();
                        lbldob.Text = dr[3].ToString();
                        lblemail.Text = dr[4].ToString();
                        lblphno.Text = dr[5].ToString();
                        lblmgr.Hide();
                        lbltl.Hide();
                    }
                }
                con.Close();
            }
             else if (ps.role == "MANAGER")
            {
                btnknow.Visible = false;
                 
            }
            con.Close();
        }

        private void leaveApplyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            le.ShowDialog();
        }

        private void lblbatch_TextChanged(object sender, EventArgs e)
        {
            le.lblbatchide.Text = lblbatch.Text;
            le.lblmgre.Text = lblmgr.Text;
            le.lbltle.Text = lbltl.Text;
        }

        private void btnleave_Click(object sender, EventArgs e)
        {
            if (ps.role == "TEAMLEADER")
            {
                teamleaderapproval tl = new teamleaderapproval();
                tl.ShowDialog();
            }
            else if (ps.role == "MANAGER")
            {
                managerapproval ma = new managerapproval();
                ma.ShowDialog();
            }
        }

        private void leaveStatusToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (ps.role == "TEAMLEADER")
            {
                teamleaderleavestatus ts = new teamleaderleavestatus();
                ts.ShowDialog();
            }
            else if (ps.role == "ASSOCIATE")
            {
                associateleavestatus ak = new associateleavestatus();
                ak.ShowDialog();
                

            }
        }

        private void leaveApprovalToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void logoutToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            string k=dateTimePicker1.Value.ToShortDateString();
            if(radioButton1.Checked==true)
            {
                con.Open();
                cmd=new SqlCommand("select cudate,msg from diary where batchid="+"'"+ps.batchid+"'" +" and cudate="+"'"+k+"'",con);
                dr=cmd.ExecuteReader();
                if(dr.HasRows)
                {
                   while(dr.Read())
                    {
                        dateTimePicker1.Text=dr[0].ToString();
                        ex = dr[0].ToString();
                        rchtxt.Text=dr[1].ToString();
                    }
                    con.Close();
                }
                else
                {
                    label4.Show();
                    label4.Text="You didn't Write the diary on this day";
                    rchtxt.Clear();
                    con.Close();
                    ex = "";
                }
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            string k = dateTimePicker1.Value.ToShortDateString();
            if (radioButton2.Checked == true)
            {
                 today = DateTime.Now.ToShortDateString();
                 if (ex != "")
                 {
                     ex = ex.Substring(0, 10);
                     if (ex == today)
                     {
                         label4.Show();
                         label4.Text = "You already wrote your diary on this day but you can update";
                         con.Open();
                         cmd = new SqlCommand("update diary set msg=" + "'" + rchtxt.Text + "'" + " where batchid=" + "'" + ps.batchid + "'" + " and cudate=" + "'" + k + "'", con);
                         cmd.ExecuteNonQuery();
                         con.Close();
                         SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\registr.wav");
                         o.Play();
                         label4.Text = "Your diary updated successfuly";
                     }
                 }
                    else
                    {
                        if (k == today)
                        {
                            con.Open();
                            //rchtxt.ReadOnly = false;
                            cmd = new SqlCommand("insert into diary values(" + "'" + ps.batchid + "'" + "," + "'" + k + "'" + "," + "'" + rchtxt.Text + "'" + ")", con);
                            cmd.ExecuteNonQuery();
                            label4.Show();
                            label4.Text = "Your diary wrote successfuly";
                            con.Close();
                        }
                        else
                        {
                            label4.Show();
                            label4.Text = "sorry you can't write on this day";
                        }
                    }
                    con.Close();
            }
        }
        private void richTextBox1_Enter(object sender, EventArgs e)
        {
            
        }

        private void button3_Click(object sender, EventArgs e)
        {
            rchtxt.Clear();
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TabIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            lblstatus.Show();
            con.Open();
            cmd = new SqlCommand("Select count(*) from sticky where id=" + "'" + ps.batchid + "'", con);
            object t = cmd.ExecuteScalar();
            con.Close();
            int co = Convert.ToInt32(t);
            if (co == 1)
            {
                con.Open();
                cmd = new SqlCommand("update sticky set remain1=" + "'" + richTextBox1.Text + "'" + ", remain2=" + "'" + richTextBox2.Text + "'" + ", remain3=" + "'" + richTextBox3.Text + "'" + " where id=" + "'" + ps.batchid + "'", con);
                cmd.ExecuteNonQuery();
                con.Close();
                SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\registr.wav");
                o.Play();
                lblstatus.Text = "Your Notes are Updated";
            }
            else if (co == 0)
            {
                con.Open();
                cmd = new SqlCommand("insert into sticky values(" + "'" + ps.batchid + "'" + "," + "'" + richTextBox1.Text + "'" + ","+"'"+richTextBox2.Text+"'"+"," + "'" + richTextBox3.Text + "'"+")", con);
                cmd.ExecuteNonQuery();
                con.Close();
                lblstatus.Text = "Your Notes are setted";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Open();
            string f = DateTime.Now.Hour.ToString();
            if (f == comboBox1.Text)
            {
                cmd = new SqlCommand("insert into timesheet values(" + "'" + ps.batchid + "'" + "," + "'" + comboBox1.Text + "'" + "," + "'" + richTextBox4.Text + "'" + ")", con);
                cmd.ExecuteNonQuery();
                con.Close();
                SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\registr.wav");
                o.Play();
                lbltimesheet.Text = "Your Work Recorded";
                fil();
            }
            else
            {
                lbltimesheet.Text = "You are doing illegal record";
            }
            con.Close();
        }
        public void fil()
        {
            con.Open();
            cmd = new SqlCommand("select dtime,rcord from timesheet where id=" + "'" + ps.batchid + "'", con);
            da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds, "time");
            con.Close();
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
        }

        private void btntime_Click(object sender, EventArgs e)
        {
            Timesheetview tv = new Timesheetview();
            tv.ShowDialog();
        }
        private void logoutToolStripMenuItem1_Click_1(object sender, EventArgs e)
        {
            j = 4;
            this.Close();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            rchtxt.ReadOnly = false;

        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            OpenFileDialog od = new OpenFileDialog();
            if (od.ShowDialog() == DialogResult.OK)
            {
                txtpictpath.Text = od.FileName;
                pictureBox1.Image = Image.FromFile(txtpictpath.Text);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            }
                if (!File.Exists("d:\\" + ps.batchid + ".txt"))
                {
                  File.WriteAllText("d:\\" + ps.batchid + ".txt", txtpictpath.Text);
                }
                else
                {
                    File.WriteAllText("d:\\" + ps.batchid + ".txt", txtpictpath.Text);
                }
        }

        public void pict()
        {
            if (File.Exists("d:\\" + ps.batchid + ".txt"))
            {
                string fn = File.ReadAllText("d:\\" + ps.batchid + ".txt");
                pictureBox1.Image = Image.FromFile(fn);
                pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
                btnpict.Text = "Change Photo";
            }
            else
            {
                btnpict.Text = "Upload Photo";
            }
        }

        private void lblavail_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblavail_Click(object sender, EventArgs e)
        {
            

        }

        private void knowTheLeaveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            knowtheleave klea = new knowtheleave();
            klea.ShowDialog();
        }

        private void btnknow_Click(object sender, EventArgs e)
        {
            knowtheleave knw = new knowtheleave();
            knw.ShowDialog();
        }

        private void Home_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        
        }
    }
