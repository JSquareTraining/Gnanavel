﻿using System;
using System.Windows.Forms;
using System.Media;
namespace WindowsFormsApplication1
{
    public partial class LeaveApply : Form
    {
        public LeaveApply()
        {
            InitializeComponent();
        }
        dataaccesslayer daccess = new dataaccesslayer();
        dataaccesslayer.leaveapply lapp=new dataaccesslayer.leaveapply();
        Properties.Settings ps = new Properties.Settings();
        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
        public void struct_leapp() //assign the value to sturcture_leaveapply in dataaccesslayer
        {
            lapp.lblbatchide=lblbatchide.Text;
            lapp.dateTimePicker1=dateTimePicker1.Text;
            lapp.dateTimePicker2=dateTimePicker2.Text;
            lapp.rtxtreason=rtxtreason.Text;
            lapp.lblnoofdays = lblnoofdays.Text;
            lapp.lbltle = lbltle.Text;
            lapp.lblmgre = lblmgre.Text;
            lapp.ps = ps.batchid;
        }
        private void LeaveApply_Load(object sender, EventArgs e)  //set minmum and maximum date in datetimepicker
        {
            dateTimePicker1.MinDate = DateTime.Now.Date.AddDays(1);  
            dateTimePicker2.MinDate = DateTime.Now.Date.AddDays(2);
            lblsuccess.Hide();
            lblbatchide.Hide();
            if (ps.role == "MANAGER")
            {
                panel1.Hide();
            }
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
        private void dateTimePicker2_ValueChanged(object sender, EventArgs e)
        {
            lblnoofdays.Text = (dateTimePicker2.Value.Subtract(dateTimePicker1.Value.Date)).ToString(); //count noofdays leave
            string[] coi = lblnoofdays.Text.Split('.');  //get the days
            lblnoofdays.Text = coi[0].ToString();
        }
        public void clr()
        {
            rtxtreason.Clear();
            lblnoofdays.Text = "";
            dateTimePicker1.Text = "";
            dateTimePicker2.Text = "";
            button1.Visible = false;
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                struct_leapp();
                int a = Convert.ToInt32(lblnoofdays.Text);
                if (a > 0 & rtxtreason.Text != "")
                {
                    if (ps.role == "ASSOCIATE")
                    {
                        try
                        {
                            int output = daccess.asso_leaveapply(lapp);//call the dataaccess layer and sturcture for associate
                            if (output >= 1)
                            {
                                lblsuccess.Show();
                                SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\leavefrd.wav");
                                o.Play();
                                lblsuccess.Text = "WAIT FOR TEAMLEADER AND MANAGER APPROVAL";
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.ToString());
                        }

                    }
                    else if (ps.role == "TEAMLEADER")
                    {
                        int output = daccess.tl_leaveapply(lapp); //call the dataaccess layer and sturcture for tl
                        lblsuccess.Show();
                        if (output >= 1)
                        {
                            lblsuccess.Show();
                            lblsuccess.Text = "WAIT FOR  MANAGER APPROVAL";
                        }
                    }
                    else if (ps.role == "MANAGER")
                    {
                        int output = daccess.mgr_leaveapply(lapp);    //call the dataaccess layer and sturcture for mgr
                        if (output >= 1)
                        {
                            lblsuccess.Show();
                            lblsuccess.Text = "YOUR LEAVE IS OWN APPROVAL";
                        }
                    }
                    clr();
                }
                else
                {
                    lblsuccess.Show();
                    lblsuccess.Text = "sorry your leave date or reason is not valid";
                    clr();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }
    }
}
