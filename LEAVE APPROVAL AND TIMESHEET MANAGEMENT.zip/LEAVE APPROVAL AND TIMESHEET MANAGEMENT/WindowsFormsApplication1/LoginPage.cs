﻿using System;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Media;
//using Microsoft.DirectX.AudioVideoPlayback;

namespace WindowsFormsApplication1
{
    public partial class LoginPage : Form
    {
        public LoginPage()
        {
            InitializeComponent();
        }
        public static int i = 0;
        private void Form1_Load(object sender, EventArgs e)
        {
            prgress.Hide();
            lblerror.Hide();
        }
        
        dataaccesslayer dacc = new dataaccesslayer();
        dataaccesslayer.login lostru = new dataaccesslayer.login();  // structure calling  classname.strucuturname objectname=new classname.strucuturname()
        int s;
        Properties.Settings ps = new Properties.Settings();
        public void struct_login() // assign  value for batchid and password to structure login
        {
            lostru.txtbatchid = txtbatchid.Text;
            lostru.txtpassword = txtpassword.Text;
            lostru.role = cmbrole.Text;
            lostru.datee = DateTime.Now.Date.ToShortDateString();
            lostru.timee = DateTime.Now.TimeOfDay.ToString();
        }
       
        private void button1_Click(object sender, EventArgs e)
        {
            struct_login();
            if (cmbrole.Text == "ASSOCIATE")
            {
                if (txtbatchid.Text != "" & txtpassword.Text != "")
                {
                    object V = dacc.logincheck(lostru);  //pass the associate(batchid and password) through structure login via dataaccesslayer
                    s = Convert.ToInt32(V);
                    SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\associate.wav");
                    o.Play();
                    if (s == 1)
                    {
                        i = 1;
                        clr();
                        this.Close();
                    }
                    else
                    {
                        lblerror.Show();
                        lblerror.Text = "Invalid Batchid/Password";
                    }
                }
            }
            else if (cmbrole.Text == "TEAMLEADER")
            {
                object V = dacc.tl_logincheck(lostru);//pass the tl(batchid and password) through structure login via dataaccesslayer
                s = Convert.ToInt32(V);
                SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\tl.wav");
                o.Play();
                if (s == 1)
                {
                    i = 1;
                    clr();
                    this.Close();
                }
                else
                {
                    lblerror.Show();
                    lblerror.Text = "Invalid Batchid/Password";
                }
            }
            else if (cmbrole.Text == "MANAGER")
            {
                object V = dacc.mgr_logincheck(lostru);//pass the mgr( batchid and password) through structure login via dataaccesslaye
                s = Convert.ToInt32(V);
               // SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorderd\mgr.wav");
                //o.Play();
                if (s == 1)
                {
                    i = 1;
                    clr();
                    this.Close();
                }
                else
                {
                    lblerror.Show();
                    lblerror.Text = "Invalid Batchid/Password";
                }
            }
            else if (cmbrole.Text == "ADMIN")
            {
                object V = dacc.admin_logincheck(lostru);
                s = Convert.ToInt32(V);
                SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\admin.wav");
                o.Play();
                if (s == 1)
                {
                    i = 2;
                    this.Close();
                    clr();
                   
                }
                else
                {
                    lblerror.Show();
                    lblerror.Text = "Invalid Batchid/Password";
                }
            }
            else
            {
                lblerror.Show();
                lblerror.Text = "Invalid user";
                
            }
            dacc.history(lostru);   
        }
      
        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            knowurbatch kb = new knowurbatch();
            kb.ShowDialog();
        }
        public void clr()
        {
            ps.batchid = txtbatchid.Text;
            ps.role = cmbrole.Text;
            ps.Save();
            prgress.Hide();
            timer1.Stop();
            txtbatchid.Clear();
            txtpassword.Clear();
            cmbrole.Text = "";
            lblerror.Hide();
        }

        private void txtbatchid_TextChanged(object sender, EventArgs e)
        {
        
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtbatchid_TextChanged_1(object sender, EventArgs e)
        {
            lblerror.Hide();
            prgress.Hide();
        }

        private void LoginPage_FormClosing(object sender, FormClosingEventArgs e)
        {
          //  Application.Exit();
        }

        public int second;
        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Interval = 300;
            timer1.Enabled = true;
            second = second + 1;
            if (prgress.Value < 80 & prgress.Value > 0)
            {
                prgress.Value = second;
            }
            else
            {
                timer1.Stop();
            }
           
        }

        private void ovalShape2_Click(object sender, EventArgs e)
        {

        }

        private void lineShape2_Click(object sender, EventArgs e)
        {

        }
    }
}
