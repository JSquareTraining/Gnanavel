﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Diagnostics;
using System.Media;
//using Excel = Microsoft.Office.Interop.Excel; //TO EXPORT THE DATAGRID VALUE TO EXCEL

namespace WindowsFormsApplication1
{
    public partial class Manager_Registration : Form
    {
        public Manager_Registration()
        {
            InitializeComponent();
        }
        SqlConnection sqlcon = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        private void button1_Click(object sender, EventArgs e)
        {
            lblerror.Hide();
            OpenFileDialog op = new OpenFileDialog();
            openFileDialog1.Filter = "excelfiles |*.xls";
            if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                txtpath.Text = openFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (txtpath.Text != "" & txtsheet.Text != "")
            {

                //if u want xlsx means "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + "C:\\Sample.xlsx" +";Extended Properties='Excel 12.0 XML;HDR=YES;';";
                try
                {
                    string path = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + txtpath.Text + ";Extended Properties=\"Excel 8.0;HDR=Yes;\";";
                    OleDbConnection conn = new OleDbConnection(path);
                    conn.Open();
                    OleDbDataAdapter da = new OleDbDataAdapter("select * from [" + txtsheet.Text + "$]", conn);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    conn.Close();
                    datagrid1.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }
            }
            else
            {
                lblerror.Show();
                lblerror.Text = "Information:(*)Fields are Required";
            }
        }

        private void Manager_Registration_Load(object sender, EventArgs e)
        {
            lblerror.Hide();
        }

        private void txtsheet_TextChanged(object sender, EventArgs e)
        {
            lblerror.Hide();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Process.Start(@"E:\JSquare\LANCE PROJECTS\ADO.NET\Monthly Winner\Monthly Winner\WindowsFormsApplication1\Resources\samples\Manager.xls");

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            try
            {
                int i=datagrid1.Rows.Count-1;
               
            foreach (DataGridViewRow valrow in this.datagrid1.Rows)
            {
                    sqlcon.Open();
                    string da = valrow.Cells[2].Value.ToString();
                    string s = "INSERT INTO manager(name,designation,dob,emailid,phno,city,sstate,country,nationality,aaddress,masterdegree,bachdegree,certification,Exper,passwor)Values(" + "'" + valrow.Cells[0].Value + "'" + "," + "'" + valrow.Cells[1].Value + "'" + "," + "'" + da + "'" + "," + "'" + valrow.Cells[3].Value + "'" + "," + "'" + valrow.Cells[4].Value + "'" + "," + "'" + valrow.Cells[5].Value + "'" + "," + "'" + valrow.Cells[6].Value + "'" + "," + "'" + valrow.Cells[7].Value + "'" + "," + "'" + valrow.Cells[8].Value + "'" + "," + "'" + valrow.Cells[9].Value + "'" + "," + "'" + valrow.Cells[10].Value + "'" + "," + "'" + valrow.Cells[11].Value + "'" + "," + "'" + valrow.Cells[12].Value + "'" + "," + "'" + valrow.Cells[13].Value + "'" + "," + "'" + valrow.Cells[14].Value + "'" + ")";
                    SqlCommand cmd = new SqlCommand(s, sqlcon);
                    cmd.CommandType = CommandType.Text;
                    cmd.ExecuteNonQuery();
                    int i1 = valrow.Index + 1;
                    if (i == i1)
                    {
                        SoundPlayer o = new SoundPlayer(@"C:\Users\SMKG\Documents\Free Sound Recorder\registr.wav");
                        o.Play();
                        MessageBox.Show("Your Entered Details Successfully Registered", "Information");
                    }
                    sqlcon.Close();
                }
               
             }
           
            
            catch
            {
                sqlcon.Close();
                datagrid1.DataSource = "";
            }
           
        }

        private void btnprint_Click(object sender, EventArgs e)
        {
            printDialog1.ShowDialog();
        }
    }
}





