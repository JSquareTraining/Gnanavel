﻿namespace WindowsFormsApplication1
{
    partial class Timesheetview
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.datagrid1 = new System.Windows.Forms.DataGridView();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.lblcan = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnmgr = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.datagrid1)).BeginInit();
            this.SuspendLayout();
            // 
            // datagrid1
            // 
            this.datagrid1.BackgroundColor = System.Drawing.Color.White;
            this.datagrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.datagrid1.GridColor = System.Drawing.Color.Green;
            this.datagrid1.Location = new System.Drawing.Point(22, 157);
            this.datagrid1.Name = "datagrid1";
            this.datagrid1.Size = new System.Drawing.Size(939, 303);
            this.datagrid1.TabIndex = 0;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(433, 96);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(171, 21);
            this.comboBox1.TabIndex = 1;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblcan
            // 
            this.lblcan.AutoSize = true;
            this.lblcan.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblcan.ForeColor = System.Drawing.Color.White;
            this.lblcan.Location = new System.Drawing.Point(271, 96);
            this.lblcan.Name = "lblcan";
            this.lblcan.Size = new System.Drawing.Size(144, 15);
            this.lblcan.TabIndex = 2;
            this.lblcan.Text = "Select The Candidate";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(457, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 15);
            this.label2.TabIndex = 2;
            this.label2.Text = "TimeSheet View";
            // 
            // btnmgr
            // 
            this.btnmgr.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnmgr.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnmgr.ForeColor = System.Drawing.Color.White;
            this.btnmgr.Location = new System.Drawing.Point(781, 112);
            this.btnmgr.Name = "btnmgr";
            this.btnmgr.Size = new System.Drawing.Size(169, 37);
            this.btnmgr.TabIndex = 3;
            this.btnmgr.Text = "FORWARD TO MANAGER";
            this.btnmgr.UseVisualStyleBackColor = true;
            this.btnmgr.Click += new System.EventHandler(this.btnmgr_Click);
            // 
            // Timesheetview
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(998, 503);
            this.Controls.Add(this.btnmgr);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lblcan);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.datagrid1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "Timesheetview";
            this.Text = "Timesheetview";
            this.Load += new System.EventHandler(this.Timesheetview_Load);
            ((System.ComponentModel.ISupportInitialize)(this.datagrid1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView datagrid1;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label lblcan;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnmgr;
    }
}