﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Timesheetview : Form
    {
        public Timesheetview()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand cmd;
        public string id;
        dataaccesslayer dacc = new dataaccesslayer();
        Properties.Settings ps = new Properties.Settings();
        private void Timesheetview_Load(object sender, EventArgs e)
        {
            if(ps.role=="TEAMLEADER")
            {
                ds = new DataSet();
                ds = dacc.tlasso(ps.batchid);
                comboBox1.DisplayMember = "name";
                comboBox1.ValueMember = "batchid";
                comboBox1.DataSource = ds.Tables[0].DefaultView;
            }
            else if (ps.role == "MANAGER")
            {
                comboBox1.Visible = false;
                btnmgr.Visible = false;
                lblcan.Visible = false;
                ds = new DataSet();
                ds = dacc.mgrtime(ps.batchid);
                datagrid1.DataSource = ds.Tables[0].DefaultView;
            }
            }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("select batchid from associate where name=" + "'" + comboBox1.Text + "'", con);
            object k = cmd.ExecuteScalar();
             con.Close();
            id = k.ToString();


            con.Open();
            da = new SqlDataAdapter("select * from timesheet where id=" + "'" + id + "'", con);
            ds = new DataSet();
            da.Fill(ds, "dffd");
            con.Close();
            datagrid1.DataSource = ds.Tables[0].DefaultView;
        }

        private void btnmgr_Click(object sender, EventArgs e)
        {
            try
            {
                int i = datagrid1.Rows.Count - 1;

                foreach (DataGridViewRow valrow in this.datagrid1.Rows)
                {
                    string fg=valrow.Cells[0].Value.ToString();
                    if (fg!="")
                    {
                        con.Open();
                        string s = "INSERT INTO timemgr Values(" + "'" + valrow.Cells[0].Value + "'" + "," + "'" + valrow.Cells[1].Value + "'" + "," + "'" + valrow.Cells[2].Value + "'" + "," + "'" + ps.mgrtime + "'" + ")";
                        SqlCommand cmd = new SqlCommand(s, con);
                        cmd.ExecuteNonQuery();
                        int i1 = valrow.Index + 1;
                        if (i == i1)
                        {
                            MessageBox.Show("this candidate details forwarded successfully", "Information");
                        }
                        con.Close();
                    }
                  
                }

            }
            catch 
            {
                con.Close();
                datagrid1.DataSource = "";
            }
        }
        }
    }

