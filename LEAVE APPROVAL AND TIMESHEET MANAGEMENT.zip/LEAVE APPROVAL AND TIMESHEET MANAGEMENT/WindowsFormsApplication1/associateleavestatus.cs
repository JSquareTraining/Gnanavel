﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class associateleavestatus : Form
    {
        public associateleavestatus()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand cmd;
        Properties.Settings ps = new Properties.Settings();
        public string s;//for delete and approve
        private void associateleavestatus_Load(object sender, EventArgs e)
        {
            fill();
        }
        public void fill()
        {

             con.Open();
             cmd = new SqlCommand("delete from fnlrecent", con);
                cmd.ExecuteNonQuery();
                con.Close();

                con.Open();
                cmd = new SqlCommand("delete from fnlcancel", con);
                cmd.ExecuteNonQuery();
                con.Close();

            //recent request in tl
            con.Open();
            cmd = new SqlCommand("insert into fnlrecent select * from TLFIRST where batchid=" + "'" + ps.batchid + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            //recent request in mgr
            con.Open();
            cmd = new SqlCommand("insert into fnlrecent select * from mgrsecond where batchid=" + "'" + ps.batchid + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            //approved leave
            con.Open();
            da = new SqlDataAdapter("select * from fnlrecent where batchid=" + "'" + ps.batchid + "'", con);
            ds = new DataSet();
            da.Fill(ds, "fnlrecent");
            con.Close();
            dtg1.DataSource = ds.Tables[0].DefaultView;

            con.Open();
            da = new SqlDataAdapter("select * from mgrapprove where batchid=" + "'" + ps.batchid + "'", con);
            ds = new DataSet();
            da.Fill(ds, "tlapprove");
            con.Close();
            dtg2.DataSource = ds.Tables[0].DefaultView;

            //cancelld leave in tl
            con.Open();
            cmd = new SqlCommand("insert into fnlcancel select * from tlcancel where batchid=" + "'" + ps.batchid + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            //cancelld leave in mgr

            con.Open();
            cmd = new SqlCommand("insert into fnlcancel select * from mgrcancel where batchid=" + "'" + ps.batchid + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            

            con.Open();
            da = new SqlDataAdapter("select * from fnlcancel where batchid=" + "'" + ps.batchid + "'", con);
            ds = new DataSet();
            da.Fill(ds, "fnlcancel");
            con.Close();
            dtg3.DataSource = ds.Tables[0].DefaultView;
        }

    }
}
