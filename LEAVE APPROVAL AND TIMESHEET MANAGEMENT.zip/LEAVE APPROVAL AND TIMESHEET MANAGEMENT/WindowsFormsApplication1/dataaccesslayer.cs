﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;

namespace WindowsFormsApplication1
{
    class dataaccesslayer
    {
        public string s;
        logicallayer logila = new logicallayer();
        public struct login
        {
          public string txtbatchid;
           public string txtpassword;
           public string datee;
           public string timee;
           public string role;
        }
        public struct leaveapply
        {
            public string lblbatchide;
            public string dateTimePicker1;
            public string dateTimePicker2;
            public string rtxtreason;
            public string lblnoofdays;
            public string lbltle;
            public string lblmgre;
            public string ps;
        }

        public object logincheck(login lo)
        {
             s="select count(*) from associate where batchid=" + "'" + lo.txtbatchid + "'" + " and passwor=" + "'" + lo.txtpassword + "'";
             return logila.scalar(s);
        }
        public object tl_logincheck(login lo)
        {
            s = "select count(*) from teamleader where tid=" + "'" + lo.txtbatchid + "'" + " and passwor=" + "'" + lo.txtpassword + "'";
            return logila.scalar(s);
        }
        public object mgr_logincheck(login lo)
        {
            s="select count(*) from manager where mgrid=" + "'" + lo.txtbatchid + "'" + " and passwor=" + "'" + lo.txtpassword + "'";
            return logila.scalar(s);
        }
        public object admin_logincheck(login lo)
        {
          s="select count(*) from admin where batchid=" + "'" + lo.txtbatchid + "'" + " and passwor=" + "'" + lo.txtpassword + "'";
          return logila.scalar(s);
        }

        public int asso_leaveapply(leaveapply leapp)
        {
            try
            {
                s = "insert into tlfirst values(" + "'" + leapp.lblbatchide + "'" + "," + "'" + leapp.dateTimePicker1 + "'" + "," + "'" + leapp.dateTimePicker2 + "'" + "," + "'" + leapp.rtxtreason + "'" + "," + "'" + leapp.lblnoofdays + "'" + "," + "'" + leapp.lbltle + "'" + "," + "'" + leapp.lblmgre + "'" + ")";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            return logila.execute(s);
        }
        public int tl_leaveapply(leaveapply leapp)
        {
            s = "insert into mgrsecond values(" + "'" + leapp.lblbatchide + "'" + "," + "'" + leapp.dateTimePicker1 + "'" + "," + "'" + leapp.dateTimePicker2 + "'" + "," + "'" + leapp.rtxtreason + "'" + "," + "'" + leapp.lblnoofdays + "'" + "," + "'" + leapp.ps + "'" + "," + "'" + leapp.lblmgre + "'" + ")";
            return logila.execute(s);
        }
        public int mgr_leaveapply(leaveapply leapp)
        {
            s = "insert into leave(batchid,fromda,todate,totalleave,,reason,availeave) values(" + "'" + leapp.lblbatchide + "'" + "," + "'" + leapp.dateTimePicker1 + "'" + "," + "'" + leapp.dateTimePicker2 + "'" + "," + "'" + leapp.lblnoofdays + "'" + "," + "'" + leapp.rtxtreason + "'" + "'" + ")";
            return logila.execute(s);
        }
        public int tl_approval(string ps)
        {
            string s = "insert into tlapprove select * from tlfirst where batchid=" + "'" + ps + "'";
            return logila.execute(s);
        }
        public int tlmgr_second(string ps)
        {
            string s = "insert into mgrsecond select * from tlfirst where batchid=" + "'" + ps + "'";
            return logila.execute(s);
        }
        public int tldelete_first(string ps)
        {
            string s = "delete from tlfirst where batchid=" + "'" + ps + "'";
            return logila.execute(s);
        }
        public int history(login lo)
        {
            s = "insert into history values(" + "'" + lo.txtbatchid + "'" + "," + "'" + lo.role + "'" + "," + "'" + lo.datee + "'" + ","+"'" + lo.timee + "'" + ")";
            return logila.execute(s);
        }
        public DataSet tlasso(string ps)
        {
            s = "select * from associate where tid=" + "'" + ps + "'";
            return logila.Adaptor(s);
        }
        public DataSet mgrtime(string ps)
        {
            s = "select * from timemgr where batchid=" + "'" + ps + "'";
            return logila.Adaptor(s);
        }

    }
}
