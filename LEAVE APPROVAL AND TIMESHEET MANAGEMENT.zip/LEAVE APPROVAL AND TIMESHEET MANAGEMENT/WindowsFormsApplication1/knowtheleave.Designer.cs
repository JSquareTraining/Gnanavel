﻿namespace WindowsFormsApplication1
{
    partial class knowtheleave
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.rtpurticular = new System.Windows.Forms.RadioButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblnotify = new System.Windows.Forms.Label();
            this.lblapplied = new System.Windows.Forms.RadioButton();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.dataGridView1.Location = new System.Drawing.Point(91, 98);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(793, 380);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(339, 36);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(172, 36);
            this.button1.TabIndex = 1;
            this.button1.Text = "KNOW THE LEAVE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(30, 43);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 2;
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // rtpurticular
            // 
            this.rtpurticular.AutoSize = true;
            this.rtpurticular.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.rtpurticular.ForeColor = System.Drawing.Color.White;
            this.rtpurticular.Location = new System.Drawing.Point(72, 6);
            this.rtpurticular.Name = "rtpurticular";
            this.rtpurticular.Size = new System.Drawing.Size(139, 19);
            this.rtpurticular.TabIndex = 3;
            this.rtpurticular.TabStop = true;
            this.rtpurticular.Text = "PARTICULAR DAY";
            this.rtpurticular.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.lblnotify);
            this.panel1.Controls.Add(this.lblapplied);
            this.panel1.Controls.Add(this.rtpurticular);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.dateTimePicker1);
            this.panel1.Location = new System.Drawing.Point(91, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(769, 81);
            this.panel1.TabIndex = 5;
            // 
            // lblnotify
            // 
            this.lblnotify.AutoSize = true;
            this.lblnotify.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnotify.ForeColor = System.Drawing.Color.Yellow;
            this.lblnotify.Location = new System.Drawing.Point(529, 49);
            this.lblnotify.Name = "lblnotify";
            this.lblnotify.Size = new System.Drawing.Size(41, 13);
            this.lblnotify.TabIndex = 6;
            this.lblnotify.Text = "label1";
            // 
            // lblapplied
            // 
            this.lblapplied.AutoSize = true;
            this.lblapplied.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblapplied.ForeColor = System.Drawing.Color.White;
            this.lblapplied.Location = new System.Drawing.Point(339, 8);
            this.lblapplied.Name = "lblapplied";
            this.lblapplied.Size = new System.Drawing.Size(172, 17);
            this.lblapplied.TabIndex = 4;
            this.lblapplied.TabStop = true;
            this.lblapplied.Text = "TOTAL APPLIED LEAVES";
            this.lblapplied.UseVisualStyleBackColor = true;
            this.lblapplied.CheckedChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // knowtheleave
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(970, 490);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.dataGridView1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "knowtheleave";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "knowtheleave";
            this.Load += new System.EventHandler(this.knowtheleave_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.RadioButton rtpurticular;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblnotify;
        private System.Windows.Forms.RadioButton lblapplied;
    }
}