﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class knowtheleave : Form
    {
        public knowtheleave()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlDataAdapter da;
        DataSet ds;
        private void button1_Click(object sender, EventArgs e)
        {

            if (rtpurticular.Checked == true)
            {
                try
                {
                    con.Open();
                    string s = "select batchid,fromda,todate,noofdays from mgrapprove where fromda=" + "'" + dateTimePicker1.Text + "'" + " or  todate=" + "'" + dateTimePicker1.Text + "'";
                    da = new SqlDataAdapter(s, con);
                    ds = new DataSet();
                    da.Fill(ds, "ddfd");
                    con.Close();
                    dataGridView1.DataSource = ds.Tables[0].DefaultView;
                   // MessageBox.Show(dataGridView1.Rows.Count.ToString());
                    if (dataGridView1.Rows.Count > 1)
                    {
                    }
                    else
                    {
                        lblnotify.Show();
                        lblnotify.Text = "No one applied the leave on this day";
                    }
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.ToString());
                }

            }
            else if(lblapplied.Checked==true)
            {
                con.Open();
                da = new SqlDataAdapter("select batchid,fromda,todate,noofdays from mgrapprove", con);
                ds = new DataSet();
                da.Fill(ds, "ddfd");
                con.Close();
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
        }

        private void knowtheleave_Load(object sender, EventArgs e)
        {
            rtpurticular.Checked = false;
            lblnotify.Hide();
            lblapplied.Checked = true;
            dateTimePicker1.MinDate = DateTime.Now.Date;
        }
     

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            dataGridView1.DataSource = "";
            lblnotify.Hide();
        }
    }
}
