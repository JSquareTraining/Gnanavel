﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class knowurbatch : Form
    {
        public knowurbatch()
        {
            InitializeComponent();
        }
        SqlConnection sqlcon = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlDataAdapter da;
        DataSet ds;
        string s;
        private void button1_Click(object sender, EventArgs e)
        {
            lblerror.Hide();
            sqlcon.Open();
            if (cmbrole.Text != "")
            {
                if (cmbrole.Text == "ASSOCIATE")
                {
                    if (txtemail.Text != "" & txtphno.Text != "" )
                    {                       
                            s = "select batchid,name,emailid,phno,passwor,mgrid,tid from associate where (" + "emailid=" + "'" + txtemail.Text + "'" + " and phno= " + "'" + txtphno.Text + "'"  + ")";
                            da = new SqlDataAdapter(s, sqlcon);
                            ds = new DataSet();
                            da.Fill(ds, "batchid");
                            sqlcon.Close();
                            progr();
                            dtgrid.DataSource = ds.Tables[0].DefaultView;
                            clr();
                    }
                    else
                    {
                        lblerror.Show();
                        lblerror.Text = "Marked(*)any two must required";
                    }
                }
                else if (cmbrole.Text == "TEAMLEADER")
                {
                    if (txtemail.Text != "" & txtphno.Text != "" )
                    {
                       s = "select tid,name,emailid,phno,passwor,mgrid from teamleader where (" + "emailid=" + "'" + txtemail.Text + "'" + " and phno=" + "'" + txtphno.Text + "'" +")";
                        da = new SqlDataAdapter(s, sqlcon);
                        ds = new DataSet();
                        da.Fill(ds, "batchid");
                        sqlcon.Close();
                        progr();
                        dtgrid.DataSource = ds.Tables[0].DefaultView;
                        clr();
                    }
                    else
                    {
                        lblerror.Show();
                        lblerror.Text = "Marked(*)any two must required";
                    }
                }
                else if (cmbrole.Text == "MANAGER")
                {
                    if (txtemail.Text != "" & txtphno.Text != "" )
                    {
                        s = "select mgrid,name,emailid,phno,passwor from manager where (" + "emailid=" + "'" + txtemail.Text + "'" + " and phno=" + "'" + txtphno.Text + "'" +")";
                        da = new SqlDataAdapter(s, sqlcon);
                        ds = new DataSet();
                        da.Fill(ds, "batchid");
                        sqlcon.Close();
                        progr();
                        dtgrid.DataSource = ds.Tables[0].DefaultView;
                        clr();
                    }
                    else
                    {
                        lblerror.Show();
                        lblerror.Text = "Marked(*)any two must required";
                    }
                }
                else
                {
                    lblerror.Show();
                    lblerror.Text = "Unknown Role";
                }
            }
            else
            {
                lblerror.Show();
                lblerror.Text = "Please Select Your Role";
            }
            sqlcon.Close();
        }
        public void progr()
        {
            for (int i = 0; i < 100; i++)
            {
                prgress.Value = i;
            }
            if (prgress.Value > 90)
            {
                prgress.Hide();
            }
        }
        public void clr()
        {
            txtemail.Clear();
            txtphno.Clear();
            cmbrole.Text = "";
            prgress.Hide();
        }
        private void knowurbatch_Load(object sender, EventArgs e)
        {
            lblerror.Hide();
            prgress.Hide();
            
        }

        private void cmbrole_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblerror.Hide();
            //txtemail.Clear();
            //txtphno.Clear();
        }

    }
}
    
