﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Data;

namespace WindowsFormsApplication1
{
    class logicallayer
    {
        Properties.Settings ps = new Properties.Settings();
        SqlCommand cmd;
        public int execute(string sql)
        {
             SqlConnection con = new SqlConnection(ps.connestr);
                con.Open();
                cmd = new SqlCommand(sql, con);
                int i=   cmd.ExecuteNonQuery();
                con.Close();
                return i;
          
        }
        public object scalar(string sql)
        {
            SqlConnection con = new SqlConnection(ps.connestr);
            con.Open();
            cmd = new SqlCommand(sql, con);
            object i = cmd.ExecuteScalar();
            con.Close();
            return i;
        }
        public SqlDataReader Reader(string sql)
        {
            SqlConnection con = new SqlConnection(ps.connestr);
            con.Open();
            SqlCommand cmd = new SqlCommand(sql, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            return dr;
        }
        public DataSet Adaptor(string sql)
        {
            SqlConnection con = new SqlConnection(ps.connestr);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(sql, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "12");
            con.Close();
            return ds;
        }
       
    }
}
