﻿using System;
using System.ComponentModel;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class teamleaderapproval : Form
    {
        public teamleaderapproval()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand cmd;
        dataaccesslayer dacc = new dataaccesslayer();
        Properties.Settings ps = new Properties.Settings();
        public string s;//for delete and approve
        public int output;
        private void teamleaderapproval_Load(object sender, EventArgs e)
        {
            fill();

        }
        public void fill()
        {
            //recent request
            con.Open();
            da = new SqlDataAdapter("select * from TLFIRST where tlid="+"'"+ps.batchid+"'", con);
            ds = new DataSet();
            da.Fill(ds, "tlfirst");
            con.Close();
            dtg1.DataSource = ds.Tables[0].DefaultView;

            //approved leave
            con.Open();
            da = new SqlDataAdapter("select * from tlapprove where tlid="+"'"+ps.batchid+"'", con);
            ds = new DataSet();
            da.Fill(ds, "tlapprove");
            con.Close();
            dtg2.DataSource = ds.Tables[0].DefaultView;

            //cancelld leave
            con.Open();
            da = new SqlDataAdapter("select * from tlcancel where tlid="+"'"+ps.batchid+"'", con);
            ds = new DataSet();
            da.Fill(ds, "tlcancel");
            con.Close();
            dtg3.DataSource = ds.Tables[0].DefaultView;
        }

        private void dtg1_CellMouseUp(object sender, DataGridViewCellMouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                this.dtg1.Rows[e.RowIndex].Selected = true;
                this.dtg1.CurrentCell = this.dtg1.Rows[e.RowIndex].Cells[1];
                this.contextMenuStrip1.Show(this.dtg1, e.Location);
                contextMenuStrip1.Show(Cursor.Position);
            }
        }

        private void approveToolStripMenuItem_Click(object sender, EventArgs e)   
        {
            try
            {
                dacc.tl_approval(s);  //tlapproval
                dacc.tlmgr_second(s); //copy to mgrsecond table
                dacc.tldelete_first(s); // delete from tltable
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }

            fill();
        }
        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {

        }

        private void contextMenuStrip1_Click(object sender, EventArgs e)
        {

        }

        private void dtg2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            s=dtg1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //move to tlcancel
            con.Open();
            cmd = new SqlCommand("insert into tlcancel select * from tlfirst where batchid=" + "'" + s + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            //delete from tlfirst
            con.Open();
            cmd = new SqlCommand("delete from tlfirst where batchid=" + "'" + s + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            fill();
        }

        private void dtg1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            s = dtg1.Rows[e.RowIndex].Cells[0].Value.ToString();
        }
    }
}

