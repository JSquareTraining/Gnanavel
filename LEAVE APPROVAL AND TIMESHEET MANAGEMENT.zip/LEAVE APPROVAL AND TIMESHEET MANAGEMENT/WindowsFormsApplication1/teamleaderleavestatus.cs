﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class teamleaderleavestatus : Form
    {
        public teamleaderleavestatus()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=decmonth;Data Source=smkg-pc");
        SqlDataAdapter da;
        DataSet ds;
        SqlCommand cmd;
        Properties.Settings ps = new Properties.Settings();
        public string s;//for delete and approve
        private void teamleaderleavestatus_Load(object sender, EventArgs e)
        {
            fill();
        }
        public void fill()
        {
            //recent request
            con.Open();
            da = new SqlDataAdapter("select * from mgrsecond where tlid=" + "'" + ps.batchid + "'", con);
            ds = new DataSet();
            da.Fill(ds, "tlfirst");
            con.Close();
            dtg1.DataSource = ds.Tables[0].DefaultView;

            //approved leave
            con.Open();
            da = new SqlDataAdapter("select * from mgrapprove where tlid=" + "'" + ps.batchid + "'", con);
            ds = new DataSet();
            da.Fill(ds, "tlapprove");
            con.Close();
            dtg2.DataSource = ds.Tables[0].DefaultView;

            //cancelld leave
            con.Open();
            da = new SqlDataAdapter("select * from mgrcancel where tlid=" + "'" + ps.batchid + "'", con);
            ds = new DataSet();
            da.Fill(ds, "tlcancel");
            con.Close();
            dtg3.DataSource = ds.Tables[0].DefaultView;
        }

        private void cancelToolStripMenuItem_Click(object sender, EventArgs e)
        {
            con.Open();
            cmd = new SqlCommand("insert into mgrcancel select * from mgrapprove where batchid=" + "'" + s + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();

            con.Open();
            cmd = new SqlCommand("delete from mgrapprove where batchid=" + "'" + s + "'", con);
            cmd.ExecuteNonQuery();
            con.Close();
            fill();
        }

    }
}
