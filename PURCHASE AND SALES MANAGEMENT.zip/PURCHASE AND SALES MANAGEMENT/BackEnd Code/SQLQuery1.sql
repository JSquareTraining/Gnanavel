create database pursal
drop table department
use pursal
create table department(did nvarchar(15)constraint didpkey primary key,dname nvarchar(15));
alter table department add id int not null
select * from department
sp_help department
drop proc departmentproc
Alter proc departmentproc
@name nvarchar(15)
as
Declare @did nvarchar(15)
Declare @prefix nvarchar(5)='D'
Declare @id int;
Declare @maxid nvarchar(max)
begin
select @maxid=ISNULL(max(id),0)+1 from department
select @did=@prefix+RIGHT('000'+CAST(@id as nvarchar(7)),7)
insert into department values(@did,@name,@id)
end
exec departmentproc '01','dfdf'
insert into department values('10','dfd','01')
select * from department
use pursal