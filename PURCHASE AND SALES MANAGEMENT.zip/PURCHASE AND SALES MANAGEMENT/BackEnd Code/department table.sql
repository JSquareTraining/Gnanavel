use pursal
CREATE TABLE DEPARTMENT
(
ID INT IDENTITY(1,1)NOT NULL,
PREFIX NVARCHAR(10)DEFAULT 'D',
DID  AS (PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
DNAME NVARCHAR(50),
CONSTRAINT DIDPKEYS PRIMARY KEY(DID ASC)
)
DROP TABLE DEPARTMENT
SELECT * FROM DEPARTMENT

delete from inward where ID>1
SP_HELP DEPARTMENT
truncate table department
INSERT INTO department(dname)VALUES('SALES')

CREATE TABLE EMPLOYEE
(
ID INT IDENTITY(1,1)NOT NULL ,
PREFIX NVARCHAR(10)DEFAULT 'E',
EID AS(PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
ENAME NVARCHAR(50),
EADDRESS NVARCHAR(100),
CITY NVARCHAR(30),
CONTACTNO NUMERIC(10)UNIQUE NOT NULL,
EMAILID NVARCHAR(30)UNIQUE NOT NULL,
DID1 NVARCHAR(17)CONSTRAINT DIDPKEYS1  FOREIGN KEY REFERENCES DEPARTMENT(DID),
CONSTRAINT EIDPKEYS PRIMARY KEY(EID ASC)
)

INSERT INTO EMPLOYEE(ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1)VALUES('LAN','CHE','CBE','9626838447','DFDFD','D1')
INSERT INTO EMPLOYEE(ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1)VALUES('lance','krishnagiri','chennai','8190962681','smkgnanavel@gmail.com','D2')
SELECT * FROM EMPLOYEE
drop table product

CREATE TABLE PRODUCT
(
ID INT IDENTITY(1,1)NOT NULL,
PREFIX NVARCHAR(10)DEFAULT 'P',
PID AS (PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
PNAME NVARCHAR(50),
PURCHASEDPRICE MONEY,
SALEPRICE MONEY,
perprice numeric(5)
CONSTRAINT PIDPKEYS PRIMARY KEY(PID ASC)
)
select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pdate between '12/1/2014' and '12/8/2014' group by i.pid order by i.pid desc
select pid from product where pid='pen'
select * from OUTWARD
select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.PDATE='2014-12-03' and o.RDATE='2014-12-03'group by i.pid
select * from inward
select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pid=o.pid and i.pdate=o.rdate group by i.pid
insert into PRODUCT(PNAME,PURCHASEDPRICE,SALEPRICE)values('pendrive','1000','1700')

create table adminlogin(username nvarchar(15)not null,password nvarchar(15)not null)
insert into adminlogin values('Lance','Lance')
select * from adminlogin

create table inward
(
ID INT IDENTITY(1,1)NOT NULL,
PREFIX NVARCHAR(10)DEFAULT 'I',
IID AS (PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
PID NVARCHAR(17) FOREIGN KEY REFERENCES PRODUCT(PID),
QTY numeric(5),
AMOUNT MONEY,
PDATE DATE,
CONSTRAINT IIDPKEYS PRIMARY KEY(IID ASC)
)

alter table inward add perprice money
select * from inward
update INWARDRETURN set stock='0'
truncaTE TABLE INWARD
DELETE FROM INWARD
select * from inward
select sum(qty) from inward where pid='P6'
select * from INWARDRETURN
select distinct (p.PURCHASEDPRICE) from product as p inner join inward as i on p.pid='p6'
insert into INWARDRETURN(IID,QTY,AMOUNT,RDATE,REASON,perprice)values('P7','3','15','12/5/2014','summa','5.0000')
select distinct p.pname from product as p inner join inward as i on i.pid=p.pid
insert into OUTWARD(PID,QTY,AMOUNT,RDATE,perprice)values('P6','0','0','12/04/2014','0');
select distinct p.PId, p.PNAME from product as p inner join inward as i on p.pid=i.pid
CREATE TABLE INWARDRETURN
(
ID INT IDENTITY(1,1)NOT NULL,
PREFIX NVARCHAR(10)DEFAULT 'IR',
IRID AS (PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
IID NVARCHAR(17) FOREIGN KEY REFERENCES INWARD(IID),
QTY numeric(5),
AMOUNT MONEY,
RDATE DATE,
REASON NVARCHAR(50),
pid nvarchar(17)
CONSTRAINT IRIDPKEYS PRIMARY KEY(IRID ASC)
)


select i.pid as productid,i.qty as boughtqty,i.amount as purchaseamount,o.qty as soldqty,o.amount as salesamount 
from inward as i inner join outward as o on i.pid=o.pid 
delete from inward where QTY=0;


select * from inward
update INWARDRETURN set AMOUNT='0',perprice='0' where stock=0
alter table INWARDRETURN add stock numeric(10)
insert into INWARDRETURN(pid)values('p6')
select * from OUTWARD
alter table INWARDRETURN add 
update INWARDRETURN set pid='p6' where pid is null
select distinct(pname) from PRODUCT where PID='p6'
select sum(QTY) from inward where pid='P6'
alter table INWARDRETURN add perprice money

insert into INWARDRETURN(IID,QTY,AMOUNT,RDATE,REASON,perprice)values('I10','5','5000.00','04/12/2014','fdfdfdf','1000.00')
select pid from product where pname='pendrive'
CREATE TABLE OUTWARD
(
ID INT IDENTITY(1,1)NOT NULL,
PREFIX NVARCHAR(10)DEFAULT 'O',
OID AS (PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
PID NVARCHAR(17) FOREIGN KEY REFERENCES PRODUCT(PID),
QTY numeric(5),
AMOUNT MONEY,
RDATE DATE,
perprice numeric(5),
CONSTRAINT OIDPKEYS PRIMARY KEY(OID ASC)
)

select * from outward
CREATE TABLE OUTWARDRETURN
(
ID INT IDENTITY(1,1)NOT NULL,
PREFIX NVARCHAR(10)DEFAULT 'IR',
ORID AS (PREFIX +RIGHT(''+CAST(ID AS NVARCHAR(7)),7))PERSISTED,
OID NVARCHAR(17) FOREIGN KEY REFERENCES OUTWARD(OID),
QTY numeric(5),
AMOUNT MONEY,
ORDATE DATE,
REASON NVARCHAR(50),
perprice money,
pid nvarchar(17),
stock numeric(5),
CONSTRAINT ORIDPKEYS PRIMARY KEY(ORID ASC)
)
select * from OUTWARDRETURN
drop table OUTWARDRETURN
alter table OUTWARDRETURN drop  column pid
alter table OUTWARDRETURN add pid nvarchar(7)
alter table OUTWARDRETURN alter column pid nvarchar(17)


sp_help OUTWARDRETURN
SELECT * FROM OUTWARDRETURN
insert into OUTWARDRETURN(OID,QTY,AMOUNT,ORDATE,REASON,perprice,pid,stock)values('O3','0','0.00','12/04/2014','fdfdfdf','0.00','p6','0')
select * from INWARDRETURN