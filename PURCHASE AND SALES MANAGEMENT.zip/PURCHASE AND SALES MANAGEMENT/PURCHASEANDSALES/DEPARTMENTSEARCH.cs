﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class DEPARTMENTSEARCH : Form
    {
        public DEPARTMENTSEARCH()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
        SqlDataAdapter da;
        private void button1_Click(object sender, EventArgs e)
        {
            if (txtdid.Text == "" & txtdept.Text != "")
            {
                con.Open();
                da = new SqlDataAdapter("select DID,DNAME from department where Dname=" + "'" + txtdept.Text + "'", con);
                con.Close();
                DataSet ds = new DataSet();
                da.Fill(ds, "Department");
                con.Close();
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Department";

            }
            else if (txtdid.Text != "" & txtdept.Text == "")
            {
                con.Open();
                da = new SqlDataAdapter("select DID,DNAME from department where DID=" + "'" + txtdid.Text + "'", con);
                con.Close();
                DataSet ds = new DataSet();
                da.Fill(ds, "Department");
                con.Close();
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Department";

            }
            else if (txtdid.Text == "" & txtdid.Text == "")
            {
                con.Open();
                MessageBox.Show("You didn't Mention the search Option");
                con.Close();
                FILL();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            FILL();
        }

        private void DEPARTMENTSEARCH_Load(object sender, EventArgs e)
        {
            FILL();
        }
        public void FILL()
        {
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter("select DID,DNAME from department", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "Department");
            con.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "Department";
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        }
    }
}
