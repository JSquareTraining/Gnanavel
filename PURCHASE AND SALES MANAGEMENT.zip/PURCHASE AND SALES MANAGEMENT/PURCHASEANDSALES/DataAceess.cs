﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Data;

namespace PURCHASEANDSALES
{
    class DataAceess
    {
        Logical ol = new Logical();
        public string str;
        public struct Product
        {
            public string pid;
            public string pname;
            public string purprice;
            public string salesprice;
            
        }
        public int Product_Registration(Product p)
        {
            str = "insert into PRODUCT(PNAME,PURCHASEDPRICE,SALEPRICE)values(" + "'" + p.pname+ "'" + "," + "'" + p.purprice + "'" + "," + "'" + p.salesprice + "'" + ")";
            ol.SQLQuery = str;
            return ol.Execute();
        
        }
        public int Product_update(Product p)
        {
             str = "update product set PNAME=" + "'" + p.pname+ "'" + "," + "PURCHASEDPRICE=" + "'" +p. purprice + "'" + "," + "SALEPRICE=" + "'" +p. salesprice + "'" + "where pid=" + "'" +p. pid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public int Product_Delete(Product p)
        {
             str = "delete from product where pid=" + "'" + p.pid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public SqlDataReader Product_Gridclick(string pid)
        {
             str = "select  pid,PNAME,PURCHASEDPRICE,SALEPRICE from product where pid=" + "'" + pid + "'";
            ol.SQLQuery = str;
            return ol.Reader();
        }
        public DataSet Product_Grid_fill()
        {
             str = "select PID,PNAME,Purchasedprice,SALEPRICE from product";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public object Product_idgen()
        {
             str = "Select pid from product where id= " + "(Select Max(id) from product)";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public int emp_registration(string txtename,string rchaddress,string txtcity,string txtcontact,string txtemail,string id)
        {
            str = "INSERT INTO EMPLOYEE(ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1)VALUES(" + "'" + txtename + "'" + "," + "'" + rchaddress + "'" + "," + "'" + txtcity + "'" + "," + "'" + txtcontact + "'" + "," + "'" + txtemail + "'" + "," + "'" + id + "'" + ")";
            ol.SQLQuery = str;
             return ol.Execute();
        }
        public int emp_update(string txtename,string rchaddress,string txtcity,string txtcontact,string txteid,string id)
        {
             str = "update employee set ename=" + "'" + txtename + "'" + "," + "eaddress=" + "'" + rchaddress + "'" + "," + "city=" + "'" + txtcity + "'" + "," + "contactno=" + "'" + txtcontact + "'" + "," + "emailid=" + "'" + txteid + "'" + " where  did1=" + "'" + id + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public int emp_delete(string txteid)
        {
             str = "delete from employee where eid=" + "'" + txteid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public DataSet emp_gridfill()
        {
            str = "select EID,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 FROM EMPLOYEE";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public SqlDataReader emp_gridclik(string txteid)
        {
             str = "select ename,eaddress,city,contactno,emailid,did1 from employee where eid=" + "'" + txteid + "'";
            ol.SQLQuery = str;
            return ol.Reader();
        }
        public object emp_scalar()
        {
             str = "Select EID from employee where id= " + "(Select Max(ID) from employee)";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public DataSet emp_deptadapter()
        {
             str = "select distinct(dname) from department";
            ol.SQLQuery = str;
            return  ol.Adaptor();
        }
        public object emp_didscaler(string txtdid1)
        {
            str = "select did from department where dname=" + "'" + txtdid1 + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public SqlDataReader emp_gridcellclick(string s)
        {
             str = "select eid,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 from employee where eid=" + "'" + s + "'";
            ol.SQLQuery = str;
            return ol.Reader();
        }
        public object dept_scalar()
        {
             str = "Select did from Department where id= " + "(Select Max(id) from department)";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public DataSet dept_fill()
        {
             str = "select DID,DNAME from department";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public int dept_insert(string comboBox1)
        {
            str = "insert into department(dname)values(" + "'" + comboBox1 + "'" + ")";
            ol.SQLQuery = str;
             return ol.Execute();
        }
        public int dept_update(string comboBox1, string textbox1)
        {
            str = "update department set dname=" + "'" + comboBox1 + "'" + " where did=" + "'" + textbox1 + "'";
            ol.SQLQuery = str;
             return ol.Execute();
        }
        public SqlDataReader dept_cellclick(string s)
        {
             str = "select  DID,DNAME from department where did=" + "'" + s + "'";
            ol.SQLQuery = str;
              return ol.Reader();

        }
        public DataSet inward_fill()
        {
             str = "select IID,PID,QTY,AMOUNT,PDATE from inward";
            ol.SQLQuery = str;
          return  ol.Adaptor();
        }
        public object inward_comboscalar()
        {
             str = "Select iid from inward where id= " + "(Select Max(id) from inward)";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public SqlDataReader inward_cmbselection(string cmb1)
        {
             str = "select PURCHASEDPRICE from product where pname=" + "'" + cmb1 + "'";
            ol.SQLQuery = str;
            return ol.Reader();
        }
        public int inward_insert(string id, string txtqty,  string txttotamount, string k, string txtamo, string cmb1)
        {
             str = "insert into inward(pid,qty,amount,pdate,perprice)values(" + "'" + id + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotamount + "'" + "," + "'" + k + "'" + "," + "'" + txtamo + "'" + ")";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public int inward_update(string cmb1, string txtqty,string txttotamount,string k,string txtiid)
        {
            str = "update inward set PID=" + "'" + cmb1 + "'" + "," + "qty=" + "'" + txtqty + "'" + "," + "amount=" + "'" + txttotamount + "'" + "," + "pdate=" + "'" + k + "'" + "WHERE iid=" + "'" + txtiid + "'";
            ol.SQLQuery = str;
             return ol.Execute();
        }
        public int inward_delete(string txtiid)
        {
             str = "delete from inward where iid=" + "'" + txtiid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public DataSet inward_combobind()
        {
            str = "select pname from product";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public SqlDataReader inward_gridcellclik(string s)
        {
            str = "select  IID,PID,perprice,QTY,AMOUNT,PDATE from inward where iid=" + "'" + s + "'";
            ol.SQLQuery = str;
              return ol.Reader();
        }
        public int outward_insert(string id, string txtqty, string txttotamount, string k, string txtamo, string cmb1)
        {
             str = "insert into outward(pid,qty,amount,pdate,perprice)values(" + "'" + id + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotamount + "'" + "," + "'" + k + "'" + "," + "'" + txtamo + "'" + ")";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public int outinward_update(string stock,string txtamo,string tot,string lblstock,string k)
        {
            str = "update inward set qty=" + "'" + stock + "'" + ",perprice=" + "'" + txtamo + "'" + ",amount=" + "'" + tot + "'" + "where qty=" + "'" + lblstock + "'" + " and pid=" + "'" + k + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public DataSet outward_fill()
        {
            str = "select OID,PID,QTY,AMOUNT,RDATE from outward";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public DataSet outward_combo()
        {
            str = "select distinct p.PId, p.PNAME from product as p inner join inward as i on p.pid=i.pid";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public object outward_formload()
        {
            str = "Select oid from outward where id= " + "(Select Max(id) from outward)";
            ol.SQLQuery = str;
            return ol.Execute_Slr();

        }
        public SqlDataReader outward_comboselect(string cmb1)
        {
            str = "select SALEPRICE from product where pname=" + "'" + cmb1 + "'";
            ol.SQLQuery = str;
            return ol.Reader();
        }
        public SqlDataReader outward_gridclick(string s)
        {
            str = "select OID,PID,QTY,AMOUNT,RDATE  from outward where Oid=" + "'" + s + "'";
            ol.SQLQuery = str;
              return ol.Reader();
        }
        public object outward_selectid(string cmb1)
        {
            str = "select pid from product where pname=" + "'" + cmb1 + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object outward_sum(string k)
        {
             str = "select sum(qty) from inward where pid=" + "'" + k + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public int inwardreturn_insert(string cmiid, string txtqty, string txttotalamount, string k, string rchtxt, string txtperprice, string id, string lblqty, string cmbiid)
        {
            str = "insert into INWARDRETURN(IID,QTY,AMOUNT,RDATE,REASON,perprice,pid,stock)values(" + "'" + cmiid + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotalamount + "'" + "," + "'" + k + "'" + "," + "'" + rchtxt + "'" + "," + "'" + txtperprice + "'" + "," + "'" + id + "'" + "," + "'" + lblqty + "'" + ")";
            ol.SQLQuery = str;
             return ol.Execute();

        }
        public int inwardreturn_update(string purqty, string amo, string tot, string id, string cmiid)
        {
            str = "update INWARD set qty=" + "'" + purqty + "'" + "," + "perprice=" + "'" + amo + "'" + "," + "amount=" + "'" + tot + "'" + " where pid=" + "'" + id + "'" + " and " + "iid=" + "'" + cmiid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public object inwardreturn_frmload()
        {
             str = "Select IRID from INWARDRETURN where id= " + "(Select Max(ID) from INWARDRETURN)";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public DataSet inwardreturn_fill()
        {
            str = "select IRID,IID,QTY,AMOUNT,RDATE,REASON,perprice,pid,stock from INWARDRETURN";
            ol.SQLQuery = str;
          return ol.Adaptor();    
        }
        public DataSet inwardreturn_inmember()
        {
            str = "select iid from inward";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public SqlDataReader inwardreturn_id(string id)
        {
            str = "select qty,perprice from INWARDRETURN where pid=" + "'" + id + "'";
            ol.SQLQuery = str;
              return ol.Reader();
        }
        public object inwardreturn_sum(string cmiid)
        {
            str = "select sum(qty) from inward where iid=" + "'" + cmiid + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object inwardreturn_disctinit(string cmiid)
        {
            str = "select distinct(pid) from inward where iid=" + "'" + cmiid + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object inwardreturn_distincproduct(string pid)
        {
            str = "select distinct(pname) from PRODUCT where PID=" + "'" + pid + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object inwardretn_comboprice(string id)
        {
            str = "select distinct (p.PURCHASEDPRICE) from product as p inner join inward as i on p.pid=" + "'" + id + "'";
            ol.SQLQuery = str;

            return ol.Execute_Slr();
        }
        public object inwaretrn_comboid(string cmbiid)
        {
            str = "select pid from product where pname=" + "'" + cmbiid + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object inwartn_combosum(string id)
        {
            str = "select sum(qty) from inward where pid=" + "'" + id + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object inwardret_iird(string s)
        {
            str = "select  IRID from INWARDRETURN where IRID=" + "'" + s + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object outwardreturn_frmload()
        {
             str = "Select ORID from OUTWARDRETURN where id= " + "(Select Max(ID) from OUTWARDRETURN)";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public DataSet outwardret_fill()
        {
             str = "select ORID,OID,QTY,AMOUNT,ORDATE,REASON,perprice,pid,stock from OUTWARDRETURN";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public DataSet outward_inmember()
        {
             str = "select Oid from outward";
            ol.SQLQuery = str;
            return ol.Adaptor();
        }
        public object outwardret_gridcellclick(string s)
        {
            str = "select  ORID from OUTWARDRETURN where ORID=" + "'" + s + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public object outcmbiid_id(string cmbiid)
        {
             str = "select pid from product where pname=" + "'" + cmbiid + "'";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public object outreturn_purprice(string id)
        {
             str = "select distinct (p.PURCHASEDPRICE) from product as p inner join outward as i on p.pid=" + "'" + id + "'";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public SqlDataReader outretrn_qtyprice(string id)
        {
            str = "select qty,perprice from OUTWARDRETURN where pid=" + "'" + id + "'";
            ol.SQLQuery = str;
              return ol.Reader();
        }
        public object outretrn_sum(string id)
        {
            str = "select sum(qty) from outward where pid=" + "'" + id + "'";
            ol.SQLQuery = str;
            return ol.Execute_Slr();
        }
        public int outward_delete(string txtrid)
        {
             str = "delete from OUTWARDRETURN where Orid=" + "'" + txtrid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
        public object outwadrre_sum(string cmiid)
        {
             str = "select sum(qty) from outward where Oid=" + "'" + cmiid + "'";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public object outred_diid(string cmiid)
        {
             str = "select distinct(pid) from outward where Oid=" + "'" + cmiid + "'";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public object outred_pname(string pid)
        {
             str = "select distinct(pname) from PRODUCT where PID=" + "'" + pid + "'";
                ol.SQLQuery = str;
                return ol.Execute_Slr();
        }
        public int outwardreturn_insert(string cmiid, string txtqty, string txttotalamount, string k, string rchtxt, string txtperprice, string id, string lblqty)
        {
            str = "insert into OUTWARDRETURN(OID,QTY,AMOUNT,ORDATE,REASON,perprice,pid,stock)values(" + "'" + cmiid + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotalamount + "'" + "," + "'" + k + "'" + "," + "'" + rchtxt + "'" + "," + "'" + txtperprice + "'" + "," + "'" + id + "'" + "," + "'" + lblqty + "'" + ")";
            ol.SQLQuery = str;
             return ol.Execute();
        }
        public int outwarreturn_outwardupdate(string purqty,string amo,string tot,string id,string cmiid)
        {
            str = "update outward set qty=" + "'" + purqty + "'" + "," + "perprice=" + "'" + amo + "'" + "," + "amount=" + "'" + tot + "'" + " where pid=" + "'" + id + "'" + " and " + "Oid=" + "'" + cmiid + "'";
            ol.SQLQuery = str;
            return ol.Execute();
        }
    }
}
