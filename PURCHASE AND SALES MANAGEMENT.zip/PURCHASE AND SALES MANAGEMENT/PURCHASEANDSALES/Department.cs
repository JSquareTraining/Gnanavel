﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class Department : Form
    {
        public Department()
        {
            InitializeComponent();
        }
        DataAceess dacc = new DataAceess();
        private void Department_Load(object sender, EventArgs e)
        {
            frmlo();
        }
        public void frmlo()
        {
            object val = dacc.dept_scalar();
            string k = val.ToString();
            string k1 = k.Remove(1);
            string k2 = k.Substring(1);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
           textBox1.Text = k1 + k3;
            fill();
        }
        public void fill()
        {
            DataSet ds = new DataSet();
            ds = dacc.dept_fill();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "12";   
        }
        private void button1_Click(object sender, EventArgs e)
        { 
            if (comboBox1.Text != "")
            {
                dacc.dept_insert(comboBox1.Text);
                comboBox1.Text = "";
                frmlo();
            }
            else
            {
                MessageBox.Show("Please Enter The Department Name");
                frmlo();
                
            }
          }
        private void button2_Click(object sender, EventArgs e)
        {
            if(comboBox1.Text!="")
            {
                dacc.dept_update(comboBox1.Text, textBox1.Text);
                    textBox1.ReadOnly = true;
                    comboBox1.Text = "";
                    frmlo();
             }
                else
                {
                    MessageBox.Show("Please Enter the Needs..Department");
                }
            }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            SqlDataReader dr;
            dr = dacc.dept_cellclick(s);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    textBox1.Text = dr[0].ToString();
                    comboBox1.Text = dr[1].ToString();
                }
            }
            else
            {

            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        }
    }

