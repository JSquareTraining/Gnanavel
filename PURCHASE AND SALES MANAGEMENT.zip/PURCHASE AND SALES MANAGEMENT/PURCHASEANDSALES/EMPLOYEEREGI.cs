﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class EMPLOYEEREGI : Form
    {
        public EMPLOYEEREGI()
        {
            InitializeComponent();
        }
        Properties.Settings ps = new Properties.Settings();
        public string id;
        public int output;
        DataAceess dacc = new DataAceess();
        deptclass dc = new deptclass();
        private void EMPLOYEEREGI_Load(object sender, EventArgs e)
        {
            fmload();
            dept();
        }

    public void fmload()
        {
            object val = dacc.emp_scalar();
            string k = val.ToString();
            string k1 = k.Remove(1);
            string k2 = k.Substring(1);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
            txteid.Text = k1 + k3;
            fill();
        }
        public void fill()
        {
            DataSet ds=new DataSet();
            ds = dacc.emp_gridfill();
            dataGridView1.DataSource=ds;
            dataGridView1.DataMember="12";
        }
              public void clr()
    {
        txtename.Clear();
        txtemail.Clear();
        txtdid1.Text = "";
        rchaddress.Text = "";
        txtcontact.Clear();
        txtcity.Clear();
        txteid.ReadOnly = true;
    }

              public void dept()
              {
                  DataSet ds = new DataSet();
                  ds = dacc.emp_deptadapter();
                  txtdid1.DisplayMember = "dname";
                  txtdid1.DataSource = ds.Tables[0].DefaultView;
               }
              private void Btn_Clk(object sender, EventArgs e)
              {
                  if (txtename.Text != "" & rchaddress.Text != "" & txtcity.Text != "" & txtcontact.Text != "" & txtemail.Text != "" & id != "")
                  {
                      if (ActiveControl.Text == "SAVE")
                      {
                          output = dacc.emp_registration(txtename.Text, rchaddress.Text, txtcity.Text, txtcontact.Text, txtemail.Text, id);
                      }
                      else if (ActiveControl.Text == "UPDATE")
                      {
                          output = dacc.emp_update(txtename.Text, rchaddress.Text, txtcity.Text, txtcontact.Text, txteid.Text, id);
                      }
                      else if (ActiveControl.Text == "DELETE")
                      {
                          output = dacc.emp_delete(txteid.Text);
                      }
                      if (output >= 1)
                      {
                          MessageBox.Show("Succeed");
                      }
                      else
                      {
                          MessageBox.Show("Operation Failed");
                      }
                  }
                  else
                  {
                      MessageBox.Show("(*)Marked fields are required");
                  }
                  fmload();
                  clr();
              }
        private void button1_Click(object sender, EventArgs e)
        {
            
        }
        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void txteid_TextChanged(object sender, EventArgs e)
        {
           
            if (txteid.ReadOnly == false)
            {
                SqlDataReader dr;
                dr = dacc.emp_gridclik(txteid.Text);
                if (dr.HasRows)
                {
                    while (dr.Read())
                    {
                        txtename.Text = dr[0].ToString();
                        rchaddress.Text = dr[1].ToString();
                        txtcity.Text = dr[2].ToString();
                        txtcontact.Text = dr[3].ToString();
                        txtemail.Text = dr[4].ToString();
                        txtdid1.Text = dr[5].ToString();
                    }
                }
                else
                {
                  
                }
                clr();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
           
            }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            SqlDataReader dr;
            dr = dacc.emp_gridcellclick(s);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txteid.Text = dr[0].ToString();
                    txtename.Text = dr[1].ToString();
                    rchaddress.Text = dr[2].ToString();
                    txtcity.Text = dr[3].ToString();
                    txtcontact.Text = dr[4].ToString();
                    txtemail.Text = dr[5].ToString();
                    txtdid1.Text = dr[6].ToString();
                }
            }
            else
            {

            }
            
        }

        private void txtdid1_SelectedIndexChanged(object sender, EventArgs e)
        {
            object dr = dacc.emp_didscaler(txtdid1.Text);
            id = dr.ToString();
        }
        }
    }

