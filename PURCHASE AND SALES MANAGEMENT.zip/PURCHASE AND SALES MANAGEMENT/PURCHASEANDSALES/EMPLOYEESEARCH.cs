﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class EMPLOYEESEARCH : Form
    {
        public EMPLOYEESEARCH()
        {
            InitializeComponent();
        }
       // Properties.Settings ps = new Properties.Settings();
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
        SqlDataAdapter da;
        private void button1_Click(object sender, EventArgs e)
        {
            if (txteid.Text != "")
            {
                con.Open();
                da = new SqlDataAdapter("select EID,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 FROM EMPLOYEE where eid=" + "'" + txteid.Text + "'", con);
                fill();
            }
            else if (txtcontact.Text != "")
            {
             
                con.Open();
                da = new SqlDataAdapter("select EID,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 FROM EMPLOYEE where CONTACTNO=" + "'" + txtcontact.Text + "'", con);
                fill();
            }
            else if (txtemail.Text != "")
            {
             
                con.Open();
                da = new SqlDataAdapter("select EID,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 FROM EMPLOYEE where EMAILID=" + "'" + txtemail.Text + "'", con);
                fill();
            }
            else if (txtname.Text != "")
            {
            
                con.Open();
                da = new SqlDataAdapter("select EID,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 FROM EMPLOYEE where ENAME=" + "'" + txtname.Text + "'", con);
                fill();
            }
            else
            {
                MessageBox.Show("You should provide  anyone existed value");
                clr();
            }
        
        }
        public void clr()
        {
            txtname.Clear();
            txtemail.Clear();
            txteid.Clear();
            txtcontact.Clear();
        }
        public void fill()
        {
            
            DataSet DS = new DataSet();
            da.Fill(DS, "EMPLOYEE");
            con.Close();
            dataGridView1.DataSource = DS;
            dataGridView1.DataMember = "EMPLOYEE";
            clr();
        }

        private void EMPLOYEESEARCH_Load(object sender, EventArgs e)
        {
            
         con.Open();
         da = new SqlDataAdapter("select EID,ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1 FROM EMPLOYEE", con);
         fill();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
