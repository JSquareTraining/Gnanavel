﻿namespace PURCHASEANDSALES
{
    partial class Homepage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.toolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.fileMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.printSetupToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.searchToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.viewMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.registrationToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.searchToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolsMenu = new System.Windows.Forms.ToolStripMenuItem();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inwardReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardReturnToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.statusToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.overallToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.reportsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.departmentDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.productDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inwardDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inwardReturnDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardReturnDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.outwardDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.profitLossDetailsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statusStrip.SuspendLayout();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // toolStripStatusLabel
            // 
            this.toolStripStatusLabel.Name = "toolStripStatusLabel";
            this.toolStripStatusLabel.Size = new System.Drawing.Size(39, 17);
            this.toolStripStatusLabel.Text = "Status";
            // 
            // statusStrip
            // 
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripStatusLabel});
            this.statusStrip.Location = new System.Drawing.Point(0, 431);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(909, 22);
            this.statusStrip.TabIndex = 2;
            this.statusStrip.Text = "StatusStrip";
            // 
            // fileMenu
            // 
            this.fileMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printSetupToolStripMenuItem,
            this.toolStripSeparator5,
            this.searchToolStripMenuItem});
            this.fileMenu.ImageTransparentColor = System.Drawing.SystemColors.ActiveBorder;
            this.fileMenu.Name = "fileMenu";
            this.fileMenu.Size = new System.Drawing.Size(82, 20);
            this.fileMenu.Text = "&Department";
            // 
            // printSetupToolStripMenuItem
            // 
            this.printSetupToolStripMenuItem.Name = "printSetupToolStripMenuItem";
            this.printSetupToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.printSetupToolStripMenuItem.Text = "Registration";
            this.printSetupToolStripMenuItem.Click += new System.EventHandler(this.printSetupToolStripMenuItem_Click);
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(134, 6);
            // 
            // searchToolStripMenuItem
            // 
            this.searchToolStripMenuItem.Name = "searchToolStripMenuItem";
            this.searchToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.searchToolStripMenuItem.Text = "Search";
            this.searchToolStripMenuItem.Click += new System.EventHandler(this.searchToolStripMenuItem_Click);
            // 
            // editMenu
            // 
            this.editMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrationToolStripMenuItem,
            this.searchToolStripMenuItem1});
            this.editMenu.Name = "editMenu";
            this.editMenu.Size = new System.Drawing.Size(71, 20);
            this.editMenu.Text = "&Employee";
            // 
            // registrationToolStripMenuItem
            // 
            this.registrationToolStripMenuItem.Name = "registrationToolStripMenuItem";
            this.registrationToolStripMenuItem.Size = new System.Drawing.Size(137, 22);
            this.registrationToolStripMenuItem.Text = "Registration";
            this.registrationToolStripMenuItem.Click += new System.EventHandler(this.registrationToolStripMenuItem_Click);
            // 
            // searchToolStripMenuItem1
            // 
            this.searchToolStripMenuItem1.Name = "searchToolStripMenuItem1";
            this.searchToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.searchToolStripMenuItem1.Text = "Search";
            this.searchToolStripMenuItem1.Click += new System.EventHandler(this.searchToolStripMenuItem1_Click);
            // 
            // viewMenu
            // 
            this.viewMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.registrationToolStripMenuItem1,
            this.searchToolStripMenuItem2});
            this.viewMenu.Name = "viewMenu";
            this.viewMenu.Size = new System.Drawing.Size(61, 20);
            this.viewMenu.Text = "&Product";
            // 
            // registrationToolStripMenuItem1
            // 
            this.registrationToolStripMenuItem1.Name = "registrationToolStripMenuItem1";
            this.registrationToolStripMenuItem1.Size = new System.Drawing.Size(137, 22);
            this.registrationToolStripMenuItem1.Text = "Registration";
            this.registrationToolStripMenuItem1.Click += new System.EventHandler(this.registrationToolStripMenuItem1_Click);
            // 
            // searchToolStripMenuItem2
            // 
            this.searchToolStripMenuItem2.Name = "searchToolStripMenuItem2";
            this.searchToolStripMenuItem2.Size = new System.Drawing.Size(137, 22);
            this.searchToolStripMenuItem2.Text = "Search";
            this.searchToolStripMenuItem2.Click += new System.EventHandler(this.searchToolStripMenuItem2_Click);
            // 
            // toolsMenu
            // 
            this.toolsMenu.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem,
            this.inwardReturnToolStripMenuItem});
            this.toolsMenu.Name = "toolsMenu";
            this.toolsMenu.Size = new System.Drawing.Size(55, 20);
            this.toolsMenu.Text = "&Inward";
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.optionsToolStripMenuItem.Text = "Inward";
            this.optionsToolStripMenuItem.Click += new System.EventHandler(this.optionsToolStripMenuItem_Click);
            // 
            // inwardReturnToolStripMenuItem
            // 
            this.inwardReturnToolStripMenuItem.Name = "inwardReturnToolStripMenuItem";
            this.inwardReturnToolStripMenuItem.Size = new System.Drawing.Size(148, 22);
            this.inwardReturnToolStripMenuItem.Text = "Inward Return";
            this.inwardReturnToolStripMenuItem.Click += new System.EventHandler(this.inwardReturnToolStripMenuItem_Click);
            // 
            // outwardToolStripMenuItem
            // 
            this.outwardToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.outwardToolStripMenuItem1,
            this.outwardReturnToolStripMenuItem});
            this.outwardToolStripMenuItem.Name = "outwardToolStripMenuItem";
            this.outwardToolStripMenuItem.Size = new System.Drawing.Size(65, 20);
            this.outwardToolStripMenuItem.Text = "&Outward";
            // 
            // outwardToolStripMenuItem1
            // 
            this.outwardToolStripMenuItem1.Name = "outwardToolStripMenuItem1";
            this.outwardToolStripMenuItem1.Size = new System.Drawing.Size(158, 22);
            this.outwardToolStripMenuItem1.Text = "Outward";
            this.outwardToolStripMenuItem1.Click += new System.EventHandler(this.outwardToolStripMenuItem1_Click);
            // 
            // outwardReturnToolStripMenuItem
            // 
            this.outwardReturnToolStripMenuItem.Name = "outwardReturnToolStripMenuItem";
            this.outwardReturnToolStripMenuItem.Size = new System.Drawing.Size(158, 22);
            this.outwardReturnToolStripMenuItem.Text = "Outward Return";
            this.outwardReturnToolStripMenuItem.Click += new System.EventHandler(this.outwardReturnToolStripMenuItem_Click);
            // 
            // menuStrip
            // 
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileMenu,
            this.editMenu,
            this.viewMenu,
            this.toolsMenu,
            this.outwardToolStripMenuItem,
            this.statusToolStripMenuItem,
            this.reportsToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Size = new System.Drawing.Size(909, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // statusToolStripMenuItem
            // 
            this.statusToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.overallToolStripMenuItem});
            this.statusToolStripMenuItem.Name = "statusToolStripMenuItem";
            this.statusToolStripMenuItem.Size = new System.Drawing.Size(51, 20);
            this.statusToolStripMenuItem.Text = "Status";
            // 
            // overallToolStripMenuItem
            // 
            this.overallToolStripMenuItem.Name = "overallToolStripMenuItem";
            this.overallToolStripMenuItem.Size = new System.Drawing.Size(111, 22);
            this.overallToolStripMenuItem.Text = "Overall";
            this.overallToolStripMenuItem.Click += new System.EventHandler(this.overallToolStripMenuItem_Click);
            // 
            // reportsToolStripMenuItem
            // 
            this.reportsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.departmentDetailsToolStripMenuItem,
            this.employeeDetailsToolStripMenuItem,
            this.productDetailsToolStripMenuItem,
            this.inwardDetailsToolStripMenuItem,
            this.inwardReturnDetailsToolStripMenuItem,
            this.outwardReturnDetailsToolStripMenuItem,
            this.outwardDetailsToolStripMenuItem,
            this.profitLossDetailsToolStripMenuItem});
            this.reportsToolStripMenuItem.Name = "reportsToolStripMenuItem";
            this.reportsToolStripMenuItem.Size = new System.Drawing.Size(59, 20);
            this.reportsToolStripMenuItem.Text = "Reports";
            // 
            // departmentDetailsToolStripMenuItem
            // 
            this.departmentDetailsToolStripMenuItem.Name = "departmentDetailsToolStripMenuItem";
            this.departmentDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.departmentDetailsToolStripMenuItem.Text = "Department Details";
            this.departmentDetailsToolStripMenuItem.Click += new System.EventHandler(this.departmentDetailsToolStripMenuItem_Click);
            // 
            // employeeDetailsToolStripMenuItem
            // 
            this.employeeDetailsToolStripMenuItem.Name = "employeeDetailsToolStripMenuItem";
            this.employeeDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.employeeDetailsToolStripMenuItem.Text = "Employee Details";
            this.employeeDetailsToolStripMenuItem.Click += new System.EventHandler(this.employeeDetailsToolStripMenuItem_Click);
            // 
            // productDetailsToolStripMenuItem
            // 
            this.productDetailsToolStripMenuItem.Name = "productDetailsToolStripMenuItem";
            this.productDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.productDetailsToolStripMenuItem.Text = "Product Details";
            this.productDetailsToolStripMenuItem.Click += new System.EventHandler(this.productDetailsToolStripMenuItem_Click);
            // 
            // inwardDetailsToolStripMenuItem
            // 
            this.inwardDetailsToolStripMenuItem.Name = "inwardDetailsToolStripMenuItem";
            this.inwardDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.inwardDetailsToolStripMenuItem.Text = "Inward Details";
            this.inwardDetailsToolStripMenuItem.Click += new System.EventHandler(this.inwardDetailsToolStripMenuItem_Click);
            // 
            // inwardReturnDetailsToolStripMenuItem
            // 
            this.inwardReturnDetailsToolStripMenuItem.Name = "inwardReturnDetailsToolStripMenuItem";
            this.inwardReturnDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.inwardReturnDetailsToolStripMenuItem.Text = "Inward Return Details";
            this.inwardReturnDetailsToolStripMenuItem.Click += new System.EventHandler(this.inwardReturnDetailsToolStripMenuItem_Click);
            // 
            // outwardReturnDetailsToolStripMenuItem
            // 
            this.outwardReturnDetailsToolStripMenuItem.Name = "outwardReturnDetailsToolStripMenuItem";
            this.outwardReturnDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.outwardReturnDetailsToolStripMenuItem.Text = "Outward Return Details";
            this.outwardReturnDetailsToolStripMenuItem.Click += new System.EventHandler(this.outwardReturnDetailsToolStripMenuItem_Click);
            // 
            // outwardDetailsToolStripMenuItem
            // 
            this.outwardDetailsToolStripMenuItem.Name = "outwardDetailsToolStripMenuItem";
            this.outwardDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.outwardDetailsToolStripMenuItem.Text = "Outward Details";
            this.outwardDetailsToolStripMenuItem.Click += new System.EventHandler(this.outwardDetailsToolStripMenuItem_Click);
            // 
            // profitLossDetailsToolStripMenuItem
            // 
            this.profitLossDetailsToolStripMenuItem.Name = "profitLossDetailsToolStripMenuItem";
            this.profitLossDetailsToolStripMenuItem.Size = new System.Drawing.Size(196, 22);
            this.profitLossDetailsToolStripMenuItem.Text = "Profit/Loss Details";
            this.profitLossDetailsToolStripMenuItem.Click += new System.EventHandler(this.profitLossDetailsToolStripMenuItem_Click);
            // 
            // Homepage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::PURCHASEANDSALES.Properties.Resources.Hw1__42_;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(909, 453);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "Homepage";
            this.Text = "Homepage";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Homepage_Load);
            this.statusStrip.ResumeLayout(false);
            this.statusStrip.PerformLayout();
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion

        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripStatusLabel toolStripStatusLabel;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripMenuItem fileMenu;
        private System.Windows.Forms.ToolStripMenuItem printSetupToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripMenuItem editMenu;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem viewMenu;
        private System.Windows.Forms.ToolStripMenuItem registrationToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem toolsMenu;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inwardReturnToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outwardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outwardToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem outwardReturnToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem searchToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statusToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem overallToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem reportsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem departmentDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem productDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inwardDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem inwardReturnDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outwardReturnDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem outwardDetailsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem profitLossDetailsToolStripMenuItem;

    }
}



