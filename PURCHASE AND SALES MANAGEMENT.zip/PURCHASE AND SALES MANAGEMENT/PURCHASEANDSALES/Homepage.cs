﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PURCHASEANDSALES
{
    public partial class Homepage : Form
    {
          public Homepage()
        {
            InitializeComponent();
        }
        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
          
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }
        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }
        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void Homepage_Load(object sender, EventArgs e)
        {
            IsMdiContainer = true;
        }

        private void printSetupToolStripMenuItem_Click(object sender, EventArgs e)
        {
             Department D= new Department();
             D.Dock = DockStyle.Fill;
             D.MdiParent = this;
             D.Show();
 
        }

        private void searchToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DEPARTMENTSEARCH ds = new DEPARTMENTSEARCH();
            ds.MdiParent = this;
            ds.Show();
        }

        private void registrationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            EMPLOYEEREGI ER = new EMPLOYEEREGI();
            ER.MdiParent= this;
            ER.Show();
        }

        private void searchToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            EMPLOYEESEARCH es = new EMPLOYEESEARCH();
            es.MdiParent = this;
            es.Show();
        }

        private void registrationToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            PRODUCTREG pr = new PRODUCTREG();
            pr.MdiParent = this;
            pr.Show();
        }

        private void searchToolStripMenuItem2_Click(object sender, EventArgs e)
        {
            ProductSearch ps = new ProductSearch();
            ps.MdiParent = this;
            ps.Show();
        }
        private void optionsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            inward iw = new inward();
            iw.MdiParent = this;
            iw.Show();
        }

        private void inwardReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            inwardreturn ir = new inwardreturn();
            ir.MdiParent = this;
            ir.Show();
        }

        private void outwardToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            outward or = new outward();
            or.MdiParent = this;
            or.Show();
        }

        private void outwardReturnToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OutwardReturn outr = new OutwardReturn();
            outr.MdiParent = this;
            outr.Show();
        }

        private void profitLossToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //ProfitOrLoss pl = new ProfitOrLoss();
            //pl.MdiParent = this;
            //pl.Show();
        }

        private void overallToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProfitOrLoss pl = new ProfitOrLoss();
            pl.MdiParent = this;
            pl.Show();
        }

        private void departmentDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Departreport dr = new Departreport();
            dr.ShowDialog();
        }

        private void employeeDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            empreport ep = new empreport();
            ep.ShowDialog();
        }

        private void productDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            prorep pr = new prorep();
            pr.ShowDialog();
        }

        private void inwardDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            inwardreport ip = new inwardreport();
            ip.ShowDialog();
        }

        private void inwardReturnDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            inretreport ir1 = new inretreport();
            ir1.ShowDialog();
        }

        private void outwardDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outreport ore = new outreport();
            ore.ShowDialog();
        }

        private void outwardReturnDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            outretunrepot outr = new outretunrepot();
            outr.ShowDialog();
        }

        private void profitLossDetailsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }   
    }
}
