﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PURCHASEANDSALES
{
    class Logical
    {
        public string _qry = "";
        public string _con="";
        public string SQLQuery 
        {
            get
            {
                return _qry;
            }
            set
            {
                _qry = value;
            }
        }
        public void Connection_String()
        {
            Properties.Settings ops = new Properties.Settings();
            _con = ops.constring;
        }

        public int Execute()
        {
            Connection_String();
            SqlConnection con = new SqlConnection(_con);
            con.Open();
            SqlCommand cmd = new SqlCommand(_qry, con);
            int i = cmd.ExecuteNonQuery();
            con.Close();
            return i;
        }
        public object Execute_Slr()
        {
            Connection_String();
            SqlConnection con = new SqlConnection(_con);
            con.Open();
            SqlCommand cmd = new SqlCommand(_qry, con);
            object i = cmd.ExecuteScalar();
            con.Close();
            return i;
        }
        public SqlDataReader  Reader()
        {
            Connection_String();
            SqlConnection con = new SqlConnection(_con);
            con.Open();
            SqlCommand cmd = new SqlCommand(_qry, con);
            SqlDataReader dr;
            dr = cmd.ExecuteReader(System.Data.CommandBehavior.CloseConnection);
            return dr;
        }
        public DataSet Adaptor()
        {
            Connection_String();
            SqlConnection con = new SqlConnection(_con);
            con.Open();
            SqlDataAdapter da = new SqlDataAdapter(_qry, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "12");
            con.Close();
            return ds;
        }
    }
}
