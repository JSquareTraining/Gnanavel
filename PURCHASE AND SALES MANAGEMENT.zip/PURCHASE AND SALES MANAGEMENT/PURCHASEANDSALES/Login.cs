﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        public static int i = 0;
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
        private void Form1_Load(object sender, EventArgs e)
        {
            lblerror.Hide();
            progressBar1.Hide();
        }
        private void btnlogin_Click(object sender, EventArgs e)
        {
            progressBar1.Show();
            if (txtusername.Text == "")
            {
                lblerror.Show();
                lblerror.Text = "UserName Shouldn't be Empty";
                progressBar1.Hide();
            }
            else if (txtpassword.Text == "")
            {
                lblerror.Show();
                lblerror.Text = "Password Shouldn't be Empty";
                progressBar1.Hide();
            }
            else
            {
                con.Open();
                if (con.State == ConnectionState.Open)
                {
                    string str = "select * from adminlogin where username= " + "'" + txtusername.Text + "'" + " And " + "password=" + "'" + txtpassword.Text + "'";
                    SqlCommand cmd = new SqlCommand(str, con);
                    cmd.ExecuteNonQuery();
                    SqlDataReader dr;
                    dr = cmd.ExecuteReader();
                    if (dr.Read())
                    {
                        if (dr.HasRows)
                        {
                            progressBar1.Show();
                            progressBar1.Value = 100;
                            txtpassword.Clear();
                            txtusername.Clear();
                            i = 1;
                            this.Close();
                        }
                        else
                        {
                            lblerror.Show();
                            lblerror.Text = "Invalid UserName/Password";
                        }
                    }
                    else
                    {
                        lblerror.Show();
                        lblerror.Text = "Invalid UserName/Password";
                    }

                }
                    con.Close();
                           }
        }

        private void txtusername_TextChanged(object sender, EventArgs e)
        {
            lblerror.Hide();
        }

        private void txtpassword_TextChanged(object sender, EventArgs e)
        {
            lblerror.Hide();
        }

        private void btncancel_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }
}
