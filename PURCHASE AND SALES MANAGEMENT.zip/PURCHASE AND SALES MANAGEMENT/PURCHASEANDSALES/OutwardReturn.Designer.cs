﻿namespace PURCHASEANDSALES
{
    partial class OutwardReturn
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblupdatestock = new System.Windows.Forms.Label();
            this.lblpqty = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.cmiid = new System.Windows.Forms.ComboBox();
            this.pnliid = new System.Windows.Forms.Panel();
            this.pnlavail = new System.Windows.Forms.Panel();
            this.lblqty = new System.Windows.Forms.Label();
            this.lblavailqty = new System.Windows.Forms.Label();
            this.cmbiid = new System.Windows.Forms.TextBox();
            this.txttotalamount = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.rchtxt = new System.Windows.Forms.RichTextBox();
            this.dtp1 = new System.Windows.Forms.DateTimePicker();
            this.txtqty = new System.Windows.Forms.TextBox();
            this.txtperprice = new System.Windows.Forms.TextBox();
            this.txtrid = new System.Windows.Forms.TextBox();
            this.pnliid.SuspendLayout();
            this.pnlavail.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // lblupdatestock
            // 
            this.lblupdatestock.AutoSize = true;
            this.lblupdatestock.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblupdatestock.ForeColor = System.Drawing.Color.Yellow;
            this.lblupdatestock.Location = new System.Drawing.Point(862, 15);
            this.lblupdatestock.Name = "lblupdatestock";
            this.lblupdatestock.Size = new System.Drawing.Size(0, 24);
            this.lblupdatestock.TabIndex = 34;
            // 
            // lblpqty
            // 
            this.lblpqty.AutoSize = true;
            this.lblpqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblpqty.ForeColor = System.Drawing.Color.White;
            this.lblpqty.Location = new System.Drawing.Point(173, 56);
            this.lblpqty.Name = "lblpqty";
            this.lblpqty.Size = new System.Drawing.Size(66, 24);
            this.lblpqty.TabIndex = 12;
            this.lblpqty.Text = "label9";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.label11.Location = new System.Drawing.Point(4, 18);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(405, 20);
            this.label11.TabIndex = 11;
            this.label11.Text = "AVAILABLE QTY OF PRODUCT UNDERTHIS IID";
            // 
            // cmiid
            // 
            this.cmiid.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.cmiid.FormattingEnabled = true;
            this.cmiid.Location = new System.Drawing.Point(398, 116);
            this.cmiid.Name = "cmiid";
            this.cmiid.Size = new System.Drawing.Size(172, 21);
            this.cmiid.TabIndex = 37;
            this.cmiid.SelectedIndexChanged += new System.EventHandler(this.cmiid_SelectedIndexChanged);
            // 
            // pnliid
            // 
            this.pnliid.Controls.Add(this.lblpqty);
            this.pnliid.Controls.Add(this.label11);
            this.pnliid.Location = new System.Drawing.Point(606, 370);
            this.pnliid.Name = "pnliid";
            this.pnliid.Size = new System.Drawing.Size(413, 120);
            this.pnliid.TabIndex = 36;
            // 
            // pnlavail
            // 
            this.pnlavail.Controls.Add(this.lblqty);
            this.pnlavail.Controls.Add(this.lblavailqty);
            this.pnlavail.Location = new System.Drawing.Point(606, 264);
            this.pnlavail.Name = "pnlavail";
            this.pnlavail.Size = new System.Drawing.Size(413, 120);
            this.pnlavail.TabIndex = 35;
            // 
            // lblqty
            // 
            this.lblqty.AutoSize = true;
            this.lblqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblqty.ForeColor = System.Drawing.Color.White;
            this.lblqty.Location = new System.Drawing.Point(173, 56);
            this.lblqty.Name = "lblqty";
            this.lblqty.Size = new System.Drawing.Size(66, 24);
            this.lblqty.TabIndex = 12;
            this.lblqty.Text = "label9";
            // 
            // lblavailqty
            // 
            this.lblavailqty.AutoSize = true;
            this.lblavailqty.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblavailqty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(128)))));
            this.lblavailqty.Location = new System.Drawing.Point(44, 18);
            this.lblavailqty.Name = "lblavailqty";
            this.lblavailqty.Size = new System.Drawing.Size(308, 24);
            this.lblavailqty.TabIndex = 11;
            this.lblavailqty.Text = "TOTAL STOCK THIS PRODUCT";
            // 
            // cmbiid
            // 
            this.cmbiid.Location = new System.Drawing.Point(398, 162);
            this.cmbiid.Name = "cmbiid";
            this.cmbiid.ReadOnly = true;
            this.cmbiid.Size = new System.Drawing.Size(172, 20);
            this.cmbiid.TabIndex = 38;
            this.cmbiid.TextChanged += new System.EventHandler(this.cmbiid_TextChanged);
            // 
            // txttotalamount
            // 
            this.txttotalamount.Location = new System.Drawing.Point(398, 312);
            this.txttotalamount.Name = "txttotalamount";
            this.txttotalamount.ReadOnly = true;
            this.txttotalamount.Size = new System.Drawing.Size(172, 20);
            this.txttotalamount.TabIndex = 33;
            // 
            // dataGridView1
            // 
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.GridColor = System.Drawing.Color.Red;
            this.dataGridView1.Location = new System.Drawing.Point(54, 529);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(942, 210);
            this.dataGridView1.TabIndex = 32;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            // 
            // button3
            // 
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.White;
            this.button3.Location = new System.Drawing.Point(606, 144);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(143, 46);
            this.button3.TabIndex = 31;
            this.button3.Text = "DELETE";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ForeColor = System.Drawing.Color.White;
            this.button1.Location = new System.Drawing.Point(606, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(143, 37);
            this.button1.TabIndex = 30;
            this.button1.Text = "SAVE";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(234, 405);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(124, 15);
            this.label7.TabIndex = 28;
            this.label7.Text = "RETURN REASON";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(234, 358);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 15);
            this.label6.TabIndex = 29;
            this.label6.Text = "DATE";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(229, 311);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(111, 15);
            this.label5.TabIndex = 27;
            this.label5.Text = "TOTAL AMOUNT";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(235, 262);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(33, 15);
            this.label4.TabIndex = 26;
            this.label4.Text = "QTY";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(234, 214);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 15);
            this.label3.TabIndex = 25;
            this.label3.Text = "PER PRICE";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(234, 110);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 15);
            this.label9.TabIndex = 24;
            this.label9.Text = "INWARD ID";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(234, 160);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(116, 15);
            this.label2.TabIndex = 23;
            this.label2.Text = "PRODUCT NAME";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(409, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(122, 15);
            this.label8.TabIndex = 22;
            this.label8.Text = "INWARD RETURN";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(229, 56);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(140, 15);
            this.label1.TabIndex = 21;
            this.label1.Text = "INWARD RETURN ID";
            // 
            // rchtxt
            // 
            this.rchtxt.Location = new System.Drawing.Point(398, 404);
            this.rchtxt.Name = "rchtxt";
            this.rchtxt.Size = new System.Drawing.Size(172, 86);
            this.rchtxt.TabIndex = 20;
            this.rchtxt.Text = "";
            // 
            // dtp1
            // 
            this.dtp1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtp1.Location = new System.Drawing.Point(398, 360);
            this.dtp1.Name = "dtp1";
            this.dtp1.Size = new System.Drawing.Size(172, 20);
            this.dtp1.TabIndex = 19;
            // 
            // txtqty
            // 
            this.txtqty.Location = new System.Drawing.Point(398, 264);
            this.txtqty.Name = "txtqty";
            this.txtqty.Size = new System.Drawing.Size(172, 20);
            this.txtqty.TabIndex = 18;
            this.txtqty.TextChanged += new System.EventHandler(this.txtqty_TextChanged);
            // 
            // txtperprice
            // 
            this.txtperprice.Location = new System.Drawing.Point(398, 217);
            this.txtperprice.Name = "txtperprice";
            this.txtperprice.ReadOnly = true;
            this.txtperprice.Size = new System.Drawing.Size(172, 20);
            this.txtperprice.TabIndex = 17;
            // 
            // txtrid
            // 
            this.txtrid.Location = new System.Drawing.Point(398, 56);
            this.txtrid.Name = "txtrid";
            this.txtrid.ReadOnly = true;
            this.txtrid.Size = new System.Drawing.Size(172, 20);
            this.txtrid.TabIndex = 16;
            // 
            // OutwardReturn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(1072, 754);
            this.Controls.Add(this.lblupdatestock);
            this.Controls.Add(this.cmiid);
            this.Controls.Add(this.pnliid);
            this.Controls.Add(this.pnlavail);
            this.Controls.Add(this.cmbiid);
            this.Controls.Add(this.txttotalamount);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.rchtxt);
            this.Controls.Add(this.dtp1);
            this.Controls.Add(this.txtqty);
            this.Controls.Add(this.txtperprice);
            this.Controls.Add(this.txtrid);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
            this.Name = "OutwardReturn";
            this.Text = "OutwardReturn";
            this.Load += new System.EventHandler(this.OutwardReturn_Load);
            this.pnliid.ResumeLayout(false);
            this.pnliid.PerformLayout();
            this.pnlavail.ResumeLayout(false);
            this.pnlavail.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblupdatestock;
        private System.Windows.Forms.Label lblpqty;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox cmiid;
        private System.Windows.Forms.Panel pnliid;
        private System.Windows.Forms.Panel pnlavail;
        private System.Windows.Forms.Label lblqty;
        private System.Windows.Forms.Label lblavailqty;
        private System.Windows.Forms.TextBox cmbiid;
        private System.Windows.Forms.TextBox txttotalamount;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox rchtxt;
        private System.Windows.Forms.DateTimePicker dtp1;
        private System.Windows.Forms.TextBox txtqty;
        private System.Windows.Forms.TextBox txtperprice;
        private System.Windows.Forms.TextBox txtrid;
    }
}