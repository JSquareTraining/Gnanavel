﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class OutwardReturn : Form
    {
        public OutwardReturn()
        {
            InitializeComponent();
        }
        public string id;
        DataAceess dacc = new DataAceess();
        public void frmload()
        {
            pnlavail.Hide();
            pnliid.Hide();
            object val = dacc.outwardreturn_frmload();  //autogenerate
            string k = val.ToString();
            string k1 = k.Remove(2);
            string k2 = k.Substring(2);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
            txtrid.Text = k1 + k3;
            fill();
            inmember();
        }
        public void fill()
        {
            DataSet ds = new DataSet();
            ds = dacc.outwardret_fill(); //grid fill
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            // dataGridView1.DataMember = "ireturn";
        }
        public void inmember()
        {
            DataSet ds1 = new DataSet();
            ds1 = dacc.outward_inmember();
            cmiid.DisplayMember = "Oid";
            cmiid.ValueMember = "Oid";
            cmiid.DataSource = ds1.Tables[0].DefaultView;
        }
        public string pntoid;
        private void cmiid_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnliid.Show();  //get sum
            object proid3 = dacc.outwadrre_sum(cmbiid.Text);
            lblpqty.Text = proid3.ToString();

            //disticnt id
            object proid = dacc.outred_diid(cmiid.Text);
            string pid = proid.ToString();



       //discticnt pname
            object proid1 = dacc.outred_pname(pid);
            cmbiid.Text = proid1.ToString();
        }

        private void OutwardReturn_Load(object sender, EventArgs e)
        {
            frmload();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbiid.Text != "" & txtperprice.Text != "" & txtqty.Text != "" & txtrid.Text != "" & txttotalamount.Text != "" & dtp1.Text != "")
            {
                // string id1 = cmbiid.SelectedValue.ToString();
                // MessageBox.Show(id);
                string k = dtp1.Value.ToShortDateString();
                dacc.outwardreturn_insert(cmiid.Text, txtqty.Text, txttotalamount.Text, k, rchtxt.Text, txtperprice.Text, id, lblpqty.Text);

                //update inward
                string tot = (Convert.ToDouble(purqty) * Convert.ToDouble(amo)).ToString();
                dacc.outwarreturn_outwardupdate(purqty, amo, tot, id, cmiid.Text);
                frmload();
                fill();
            }
            else
            {
                MessageBox.Show("Mentioned fields are required");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        { //delete
            dacc.outward_delete(txtrid.Text);
            MessageBox.Show(txtrid.Text, "Deleted");
            fill();
            frmload();
        }
        public string qty, amo;
        public string purqty, totstock;
        private void txtqty_TextChanged(object sender, EventArgs e)
        {
            if (txtqty.Text != "" & txtperprice.Text != "")
            {
                double s = Convert.ToDouble(txtqty.Text) * Convert.ToDouble(txtperprice.Text);
                txttotalamount.Text = s.ToString();
                if (Convert.ToDouble(lblpqty.Text) >= Convert.ToDouble(txtqty.Text))
                {
                    //stock getting
                    SqlDataReader dr;
                    dr = dacc.outretrn_qtyprice(id);
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            qty = dr[0].ToString();
                            amo = dr[1].ToString();
                        }
                    }
                    purqty = (Convert.ToDouble(lblpqty.Text) - (Convert.ToDouble(txtqty.Text) + Convert.ToDouble(qty))).ToString();
                    totstock = (Convert.ToDouble(lblqty.Text) - Convert.ToDouble(purqty)).ToString();

                    //update stock


                }
                else
                {
                    MessageBox.Show(lblpqty.Text, "Total Available qty of product UNDER THIS IID");
                    txtqty.Clear();
                }
            }
            else if (txtqty.Text == "" & txtperprice.Text != "")
            {
                txttotalamount.Text = txtperprice.Text;
            }
        }

        private void cmbiid_TextChanged(object sender, EventArgs e)
        {
            
            object d = dacc.outcmbiid_id(cmbiid.Text); //id select
            id = d.ToString();
             //purchasse price
         
            object dr = dacc.outreturn_purprice(id);
            txtperprice.Clear();
            txtperprice.Text = dr.ToString();


            pnlavail.Show();
            object var = dacc.outretrn_sum(id);
            lblqty.Text = var.ToString();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            object dr = dacc.outwardret_gridcellclick(s);
            txtrid.Text = dr.ToString();
        }
    }
}
