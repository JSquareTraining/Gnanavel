﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class PRODUCTREG : Form
    {
        public PRODUCTREG()
        {
            InitializeComponent();
        }
 
        DataAceess od = new DataAceess();
        DataAceess.Product odp = new DataAceess.Product();
        private void PRODUCTREG_Load(object sender, EventArgs e)
        {
            frmlo();
            fill();
        }
        public void frmlo()
        {
            object val = od.Product_idgen();
            string k = val.ToString();
            string k1 = k.Remove(1);
            string k2 = k.Substring(1);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
            txtpid.Text = k1 + k3;
         
            
        }
        public void fill()
        {
        
            DataSet ds = new DataSet();
            ds = od.Product_Grid_fill();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "12";
            
        }
        public void CLR()
        {
            txtpname.Clear();
            txtpurchaseprice.Clear();
            txtsalesprice.Clear();
            txtpid.ReadOnly = true;
        }
        public void Struct_init()
        {
            odp.pid = txtpid.Text;
            odp.pname = txtpname.Text;
            odp.purprice = txtpurchaseprice.Text;
            odp.salesprice = txtsalesprice.Text;
        }
        private void Btn_clk(object sender, EventArgs e)
        {
            Struct_init();
            if (ActiveControl.Text == "SAVE")
            {
                if (Convert.ToDouble(txtsalesprice.Text) >= Convert.ToDouble(txtpurchaseprice.Text))
                {
                    int i = od.Product_Registration(odp);
                    if (i >= 1)
                    {
                        MessageBox.Show("product registered successfully");
                    }               
                }
            }
            else if (ActiveControl.Text == "UPDATE")
            {
                if (txtpurchaseprice.Text != "" & txtsalesprice.Text != "" & txtpname.Text != "")
                {
                    int i = od.Product_update(odp);
                    if (i >= 1)
                    {
                        MessageBox.Show("product updated");
                    }                  
                }
               
            }
            else if (ActiveControl.Text == "DELETE")
            {
                if (txtpid.Text != "")
                {
                    int i = od.Product_Delete(odp);
                    if (i >= 1)
                    {
                        MessageBox.Show("Deleted");
                    }                   
                }
               
            }
            frmlo();
            fill();
            CLR();
        }
      

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            SqlDataReader dr;
            dr = od.Product_Gridclick(s);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txtpid.Text = dr[0].ToString();
                    txtpname.Text = dr[1].ToString();
                    txtpurchaseprice.Text = dr[2].ToString();
                    txtsalesprice.Text = dr[3].ToString();
                }
            }
          
        }
    }
}
