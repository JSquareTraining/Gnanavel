﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PURCHASEANDSALES
{
    public partial class ProductSearch : Form
    {
        public ProductSearch()
        {
            InitializeComponent();
        }
        SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
        SqlDataAdapter da;
        string str;
        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            if (txtpid.Text != "")
            {
                str = "select PID,PNAME,Purchasedprice,SALEPRICE from product where pid=" + "'" + txtpid.Text + "'";
                bal();
            }
            else if (txtpname.Text != "")
            {
                str = "select PID,PNAME,Purchasedprice,SALEPRICE from product where pname=" + "'" + txtpname.Text + "'";
                bal();
            }
            else if (txtprice.Text != "")
            {
                str = "select PID,PNAME,Purchasedprice,SALEPRICE from product where SALEPRICE=" + "'" + txtprice.Text + "'";
                bal();
            }
          
        }
        public void bal()
        {
            da = new SqlDataAdapter(str, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "product");
            con.Close();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "product";
        }

        private void ProductSearch_Load(object sender, EventArgs e)
        {
            con.Open();
            str = "select PID,PNAME,Purchasedprice,SALEPRICE from product";
            bal();
        }
    }
}
