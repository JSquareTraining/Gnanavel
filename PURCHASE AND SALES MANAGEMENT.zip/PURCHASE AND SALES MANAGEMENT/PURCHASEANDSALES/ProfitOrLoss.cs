﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class ProfitOrLoss : Form
    {
        public ProfitOrLoss()
        {
            InitializeComponent();
        }
        Properties.Settings ps = new Properties.Settings();
       SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
        SqlDataAdapter da;
        private void ProfitOrLoss_Load(object sender, EventArgs e)
        {
            //panel2.Hide();
            //panel4.Hide();
           // SqlConnection con = new SqlConnection(ps.k);
            con.Open();
            da = new SqlDataAdapter("select pname from product", con);
            DataSet ds = new DataSet();
            da.Fill(ds, "dname");
            con.Close();
            cmbpid.DisplayMember = "pname";
            cmbpid.ValueMember = "pid";
            cmbpid.DataSource = ds.Tables[0].DefaultView;
 
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            panel2.Hide();
            panel4.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //if (radioButton1.Checked == true)
            //{

            //}
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
  
        }

        private void radioButton1_CheckedChanged_1(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
             //   SqlConnection con = new SqlConnection(ps.k);
                string k = dateTimePicker1.Value.ToShortDateString();
                con.Open();
                string s = "select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pdate=" + "'" + k + "'" + " and o.rdate=" + "'" + k + "'" + "group by i.pid";
                //da = new SqlDataAdapter(s, con);
                //DataSet ds = new DataSet();
                //da.Fill(ds, "val");              
                //con.Close();
                //dataGridView1.DataSource = ds.Tables[0].DefaultView;
                //con.Close();
                //con.Open();

                //da = new SqlDataAdapter(s, con);  //crystal report add  dynamic
                //DataSet1 dss = new DataSet1();
                //da.Fill(dss, "DataTable1");
                //CrystalReport1 c = new CrystalReport1();
                ////cry c = new cry();
                //c.SetDataSource(dss);
                //crystalReportViewer1.ReportSource = c;
                //crystalReportViewer1.Refresh();
                //con.Close();
            }
            else if (radioButton2.Checked==true)
            {
               // SqlConnection con = new SqlConnection(ps.k);
             con.Open();
            string s = "select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pid=o.pid group by i.pid order by i.pid desc";
            da = new SqlDataAdapter(s, con);
            DataSet ds = new DataSet();
            da.Fill(ds, "val");
            con.Close();
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            else if (radioButton3.Checked == true)
            {
                //SqlConnection con = new SqlConnection(ps.k);
                string k = dateTimePicker1.Value.ToShortDateString();
                string k1 = dateTimePicker2.Value.ToShortDateString();
                con.Open();
                string s = "select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pdate between"+ "'" + k + "'"+"and" +"'" + k1 + "'"+"and o.rdate between"+ "'" + k + "'"+"and" +"'" + k1 + "'"+"group by i.pid order by i.pid desc";
                da = new SqlDataAdapter(s, con);
                DataSet ds = new DataSet();
                da.Fill(ds, "val");
                con.Close();
                dataGridView1.DataSource = ds.Tables[0].DefaultView;
            }
            if (radioButton4.Checked == true)
            {
                //SqlConnection con = new SqlConnection(ps.k);
                con.Open();
               // string s="select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pid=o.pid group by i.pid order by i.pid desc"
                SqlCommand cmd = new SqlCommand("select distinct(pid)from product where pname=" + "'" + cmbpid.Text + "'", con);
                object proid = cmd.ExecuteScalar();
                con.Close();
                string pid = proid.ToString();
                if (pid != "")
                {
                    con.Open();
                    string s = "select i.pid as productid,sum(i.qty)as boughtqty,sum(i.amount) as purchaseamount,sum(o.amount) as salesamount from inward as i inner join outward as o on i.pid=" + "'" + pid + "'" + " and o.pid=" + "'" + pid + "'" + " group by i.pid order by i.pid desc";
                //SqlDataAdapter da=new SqlDataAdapter(s,con);
                //DataSet ds = new DataSet();
                //da.Fill(ds, "si");
                //con.Close();
                //dataGridView1.DataSource = ds.Tables[0].DefaultView;
                    //con.Close();
                    //da = new SqlDataAdapter(s, con);  //crystal report add  dynamic
                    //DataSet1 dss = new DataSet1();
                    //da.Fill(dss, "DataTable1");
                    //CrystalReport1 c = new CrystalReport1();
                    ////cry c = new cry();
                    //c.SetDataSource(dss);
                    //crystalReportViewer1.ReportSource = c;
                    //crystalReportViewer1.Refresh();
                    //con.Close();
                
                }
            }
        }

        private void cmbpid_SelectedIndexChanged(object sender, EventArgs e)
        {
          
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {

        }
        
    }
}
