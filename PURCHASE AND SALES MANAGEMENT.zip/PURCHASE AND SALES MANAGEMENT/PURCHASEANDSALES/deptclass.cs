﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PURCHASEANDSALES
{
   public class deptclass
    {
       SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
       SqlCommand cmd;
       public void deptinsert(string comboBox1)
       {
           con.Open();
           string s = "insert into department(dname)values(" + "'" + comboBox1 + "'" + ")";
           SqlCommand cmd = new SqlCommand(s, con);
           cmd.ExecuteNonQuery();
           MessageBox.Show("Inserted");
           con.Close();
       }
       public void deptupdate(string comboBox1,string textbox1)
       {
             con.Open();
             string s = "update department set dname=" + "'" + comboBox1 + "'" + " where did=" + "'" + textbox1 + "'";
             SqlCommand cmd = new SqlCommand(s, con);
             cmd.ExecuteNonQuery();
             MessageBox.Show("Department Updated");
             con.Close();
       }
       public void empinsert(string txtename,string rchaddress,string txtcity,string txtcontact, string txtemail,string id)
       {
            con.Open();
            string str = "INSERT INTO EMPLOYEE(ENAME,EADDRESS,CITY,CONTACTNO,EMAILID,DID1)VALUES(" + "'" + txtename + "'" + "," + "'" + rchaddress+ "'" + "," + "'" + txtcity + "'" + "," + "'" + txtcontact+ "'" + "," + "'" + txtemail + "'" + "," + "'" + id + "'" + ")";
            cmd = new SqlCommand(str, con);
            cmd.ExecuteNonQuery();
            con.Close();
            MessageBox.Show(txtename, "Inserted");
       }
       public void empupdate(string txtename,string rchaddress,string txtcity,string txtcontact,string txteid,string id)
       {
           con.Open();
           string str = "update employee set ename=" + "'" + txtename + "'" + "," + "eaddress=" + "'" + rchaddress + "'" + "," + "city=" + "'" + txtcity + "'" + "," + "contactno=" + "'" + txtcontact + "'" + "," + "emailid=" + "'" + txteid + "'" + " where  did1=" + "'" + id + "'";
           cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show("Updated");
       }
       public void empdelete(string txteid, string txtename)
       {
           con.Open();
           string str = "delete from employee where eid=" + "'" + txteid + "'";
           cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(txtename, "deleted");
       }
       public void inwardinsert(string id, string txtqty, string txttotamount,string k,string txtamo,string cmb1)
       {
           con.Open();
           string str = "insert into inward(pid,qty,amount,pdate,perprice)values(" + "'" + id + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotamount + "'" + "," + "'" + k + "'" + "," + "'" + txtamo + "'" + ")";
           SqlCommand cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(cmb1, "Inserted");
       }
       public void inwardupdate(string cmb1, string txtqty, string txttotamount, string k, string txtiid)
       {
           con.Open();
           string s = "update inward set PID=" + "'" + cmb1 + "'" + "," + "qty=" + "'" + txtqty + "'" + "," + "amount=" + "'" + txttotamount + "'" + "," + "pdate=" + "'" + k + "'" + "WHERE iid=" + "'" + txtiid + "'";
           SqlCommand cmd = new SqlCommand(s, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(cmb1, "Updated");
       }
       public void inwarddelete(string txtiid)
       {
           con.Open();
           string str = "delete from inward where iid=" + "'" + txtiid + "'";
           SqlCommand cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(txtiid, "Record Deleted");
       }
       public void inwardreturninsert(string cmiid, string txtqty, string txttotalamount, string k, string rchtxt, string txtperprice, string id, string lblqty,string cmbiid)
       {
           con.Open();
           string s = "insert into INWARDRETURN(IID,QTY,AMOUNT,RDATE,REASON,perprice,pid,stock)values(" + "'" + cmiid + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotalamount + "'" + "," + "'" + k + "'" + "," + "'" + rchtxt + "'" + "," + "'" + txtperprice + "'" + "," + "'" + id + "'" + "," + "'" + lblqty + "'" + ")";
           cmd = new SqlCommand(s, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(cmbiid, "Inserted");
       }
       public void inwardreturndelete(string txtrid)
       {
           con.Open();
           string str = "delete from INWARDRETURN where irid=" + "'" + txtrid + "'";
           cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(txtrid, "Deleted");
       }
       public void inwardreturnupdate(string purqty,string amo,string tot,string id,string cmiid)
       {
           con.Open();
           string s1 = "update INWARD set qty=" + "'" + purqty + "'" + "," + "perprice=" + "'" + amo + "'" + "," + "amount=" + "'" + tot + "'" + " where pid=" + "'" + id + "'" + " and " + "iid=" + "'" + cmiid + "'";
           cmd = new SqlCommand(s1, con);
           cmd.ExecuteNonQuery();
           con.Close();
       }
       public void outwardsinsert(string stock, string txtamo, string tot, string lblstock,string k)
       {
           con.Open();
           String iu = "update inward set qty=" + "'" + stock + "'" + ",perprice=" + "'" + txtamo + "'" + ",amount=" + "'" + tot + "'" + "where qty=" + "'" + lblstock + "'" + " and pid=" + "'" + k + "'";
           SqlCommand cmd1 = new SqlCommand(iu, con);
           cmd1.ExecuteNonQuery();
           con.Close();
       }
       public void outwardinsert(string id, string txtqty, string txttotamount, string k1, string txtamo,string cmb1)
       {
           con.Open();
           string str = "insert into outward(pid,qty,amount,rdate,perprice)values(" + "'" + id + "'" + "," + "'" + txtqty + "'" + "," + "'" + txttotamount + "'" + "," + "'" + k1 + "'" + "," + "'" + txtamo + "'" + ")";
           SqlCommand cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(cmb1, "Inserted");
       }
       public void outwarddelete(string txtiid)
       {
           con.Open();
           string str = "delete from outward where Oid=" + "'" + txtiid + "'";
           SqlCommand cmd = new SqlCommand(str, con);
           cmd.ExecuteNonQuery();
           con.Close();
           MessageBox.Show(txtiid, "Record Deleted");
       }
    }
}
