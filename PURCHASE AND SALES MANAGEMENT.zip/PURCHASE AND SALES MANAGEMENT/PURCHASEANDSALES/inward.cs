﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace PURCHASEANDSALES
{
    public partial class inward : Form
    {
        public inward()
        {
            InitializeComponent();
        }
        DataSet ds = new DataSet();
        DataAceess dacc = new DataAceess();
        public string id;
        deptclass dc = new deptclass();
        private void inward_Load(object sender, EventArgs e)
        {
            frmload();
            fill();
            combo();
            clr();
        }
        public void fill()
        {
            ds = dacc.inward_fill();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "12";
        }
        public void combo()
        {
             DataSet ds = new DataSet();
            ds = dacc.inward_combobind();
            cmb1.DisplayMember = "pname";
            cmb1.ValueMember = "pid";
            cmb1.DataSource = ds.Tables[0].DefaultView;
        }
        public void frmload()
        {
            object val = dacc.inward_comboscalar();
            string k = val.ToString();
            string k1 = k.Remove(1);
            string k2 = k.Substring(1);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
            txtiid.Text = k1 + k3;
    }

        private void cmb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataReader dr;
            id = cmb1.SelectedValue.ToString();
            dr = dacc.inward_cmbselection(cmb1.Text);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txtamo.Text = dr[0].ToString();
                }
            }
            else
            {
                
            }
        }
        public void clr()
        {
            txtqty.Clear();
            txttotamount.Clear();
            txtamo.Clear();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string k = dtp.Value.ToShortDateString();
            dacc.inward_insert(id, txtqty.Text, txttotamount.Text, k, txtamo.Text, cmb1.Text);
            frmload();
            fill();
            combo();
            clr();
        }

        private void txtqty_TextChanged(object sender, EventArgs e)
        {
            if (txtqty.Text != "" & txtamo.Text!="")
            {
                dynamic k = (Convert.ToDouble(txtqty.Text)) * (Convert.ToDouble(txtamo.Text));
                txttotamount.Text = k.ToString();
            }
            else
            {
                txttotamount.Text = txtamo.Text;
            }
        }

        private void txtamo_TextChanged(object sender, EventArgs e)
        {
            txttotamount.Text = txtamo.Text;
            txtqty.Clear();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {   
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            SqlDataReader dr;
            dr = dacc.inward_gridcellclik(s);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txtiid.Text=dr[0].ToString();
                    cmb1.Text=dr[1].ToString();
                    txtamo.Text = dr[2].ToString();
                    txtqty.Text=dr[3].ToString();
                    txttotamount.Text=dr[4].ToString();
                    dtp.Text=dr[5].ToString();
                }
            }
            else
            {

            }
        }
        
        private void button2_Click(object sender, EventArgs e)
        {
            string k = dtp.Value.ToShortDateString();
            dacc.inward_update(cmb1.Text, txtqty.Text, txttotamount.Text, k, txtiid.Text);
            frmload();
            fill();
            combo();
            clr();
        }
        private void button3_Click(object sender, EventArgs e)
        {
            dacc.inward_delete(txtiid.Text);
            fill();
            combo();
            clr();
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {

        }
        private void txtiid_TextChanged(object sender, EventArgs e)
        {

        }
        }
    }

