﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class inwardreturn : Form
    {
        public inwardreturn()
        {
            InitializeComponent();
        }

        public string id;
        deptclass dc = new deptclass();
        DataAceess dacc = new DataAceess();
        private void inwardreturn_Load(object sender, EventArgs e)
        {
            frmload();
        }
        public void frmload()
        {
            pnlavail.Hide();
            pnliid.Hide();
            object val = dacc.inwardreturn_frmload(); //auto generate no.
            string k = val.ToString();
            string k1 = k.Remove(2);
            string k2 = k.Substring(2);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
            txtrid.Text = k1 + k3;
            fill();
            inmember();
        }
        public void fill()
        {
            DataSet ds = new DataSet();
            ds = dacc.inwardreturn_fill(); //grid fill
            dataGridView1.DataSource = ds.Tables[0].DefaultView;
          //  dataGridView1.DataMember = "12";
        }
        public void inmember()
        {
               DataSet ds1 = new DataSet();
               ds1 = dacc.inwardreturn_inmember(); //combo inmeme
               cmiid.DisplayMember = "iid";
               cmiid.ValueMember = "iid";
               cmiid.DataSource = ds1.Tables[0].DefaultView;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (cmbiid.Text != "" & txtperprice.Text != "" & txtqty.Text != "" & txtrid.Text != "" & txttotalamount.Text != "" & dtp1.Text != "")
            {
                string k = dtp1.Value.ToShortDateString(); //inwarretu insert
                dacc.inwardreturn_insert(cmbiid.Text, txtqty.Text, txttotalamount.Text, k, rchtxt.Text, txtperprice.Text, id, lblqty.Text, cmbiid.Text);
               //update inward

                    string tot = (Convert.ToDouble(purqty) * Convert.ToDouble(amo)).ToString();
                    dacc.inwardreturn_update(purqty, amo, tot, id, cmiid.Text);
                    frmload();
                    fill();
            }
            else
            {
                MessageBox.Show("Mentioned fields are required");
            }
        }

        private void cmbiid_SelectedIndexChanged(object sender, EventArgs e)
        {
           

        }
        public string qty,amo;
        public string purqty, totstock;
        private void txtqty_TextChanged(object sender, EventArgs e)
        {
            if (txtqty.Text != "" & txtperprice.Text != "")
            {
                double s = Convert.ToDouble(txtqty.Text) * Convert.ToDouble(txtperprice.Text);
                txttotalamount.Text = s.ToString();
                if (Convert.ToDouble(lblpqty.Text) >= Convert.ToDouble(txtqty.Text))
                {
                    //stock getting
                    SqlDataReader dr;
                    dr = dacc.inwardreturn_id(id);
                    if (dr.HasRows)
                    {
                        while (dr.Read())
                        {
                            qty = dr[0].ToString();
                             amo = dr[1].ToString();
                        }
                    }
                   
                    purqty = (Convert.ToDouble(lblpqty.Text) - (Convert.ToDouble(txtqty.Text) + Convert.ToDouble(qty))).ToString();
                    totstock = (Convert.ToDouble(lblqty.Text) - Convert.ToDouble(purqty)).ToString();

                    //update stock
                 

                }
                else
                {
                    MessageBox.Show(lblpqty.Text, "Total Available qty of product UNDER THIS IID");
                    txtqty.Clear();
                }
            }
            else    if (txtqty.Text == "" & txtperprice.Text!="")
            {
                txttotalamount.Text = txtperprice.Text;
            }
        }

        public string pntoid; 
        private void cmiid_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnliid.Show();

            //calculate sum
            object proid3 = dacc.inwardreturn_sum(cmiid.Text);
            lblpqty.Text = proid3.ToString();

            
 //distinct id
            object proid = dacc.inwardreturn_disctinit(cmiid.Text);
            string pid = proid.ToString();
            

//distinct product
            object proid1 = dacc.inwardreturn_distincproduct(pid);
            cmbiid.Text=proid1.ToString();
 
        }

        private void cmbiid_TextChanged(object sender, EventArgs e)
        {
 //id getting
            object d = dacc.inwaretrn_comboid(cmbiid.Text);
             id = d.ToString();

//price getting
            object dr = dacc.inwardretn_comboprice(id);
            txtperprice.Clear();
            txtperprice.Text = dr.ToString();

//qty sum
            pnlavail.Show();
            object var = dacc.inwartn_combosum(id);
            lblqty.Text = var.ToString();

        }

        private void txtperprice_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            object dr = dacc.inwardret_iird(s);  //return iird
           txtrid.Text = dr.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dc.inwardreturndelete(txtrid.Text); //delete 
            fill();
            frmload();
        }

        private void txtrid_TextChanged(object sender, EventArgs e)
        {

        }
        
    }
}
