﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace PURCHASEANDSALES
{
    public partial class outward : Form
    {
        public outward()
        {
            InitializeComponent();
        }
        public string id;
        public string k;
        public int stock;
        DataAceess dacc = new DataAceess();
        deptclass dc = new deptclass();
        private void txtiid_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtamo_TextChanged(object sender, EventArgs e)
        {
            txttotamount.Text = txtamo.Text;
            txtqty.Clear();
        }

        private void outward_Load(object sender, EventArgs e)
        {
            frmload();
            fill();
            combo();
        }
        public void clr()
        {
            txtqty.Clear();
            txttotamount.Clear();
            txtamo.Clear();
        }
        public void fill()
        {
            DataSet ds = new DataSet();
            ds = dacc.outward_fill();
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "12";
        }
        public void combo()
        {
            
            DataSet ds = new DataSet();
            ds = dacc.outward_combo();
            cmb1.DisplayMember = "pname";
            cmb1.ValueMember = "pid";
            cmb1.DataSource = ds.Tables[0].DefaultView;
        }
        public void frmload()
        {
            object val = dacc.outward_formload();
            string k = val.ToString();
            string k1 = k.Remove(1);
            string k2 = k.Substring(1);
            string k3 = (Convert.ToDouble(k2) + Convert.ToDouble(1)).ToString();
            txtiid.Text = k1 + k3;
        }

        private void cmb1_SelectedIndexChanged(object sender, EventArgs e)
        {
            SqlDataReader dr;
            id = cmb1.SelectedValue.ToString();
            dr = dacc.outward_comboselect(cmb1.Text);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txtamo.Text = dr[0].ToString();
                }
            }
            else
            {

            }
            //dfd

            object k1 = dacc.outward_selectid(cmb1.Text);
            k = k1.ToString();

    
            object n = dacc.outward_sum(k);
            lblstock.Text = n.ToString();
            
        }

        private void dtp_ValueChanged(object sender, EventArgs e)
        {

        }

        private void txtqty_TextChanged(object sender, EventArgs e)
        {

            if (Convert.ToInt32(lblstock.Text) >= 1)
            {
                if (txtqty.Text!="")
                {
                    if (Convert.ToInt32(txtqty.Text) <= (Convert.ToInt32(lblstock.Text)))
                    {
                        stock = (Convert.ToInt32(lblstock.Text) - Convert.ToInt32(txtqty.Text));

                        if (txtqty.Text != "" & txtamo.Text != "")
                        {
                            dynamic k = (Convert.ToDouble(txtqty.Text)) * (Convert.ToDouble(txtamo.Text));
                            txttotamount.Text = k.ToString();

                        }
                        else
                        {
                            txttotamount.Text = txtamo.Text;
                        }
                    }
                    else
                    {
                        txtqty.Clear();
                        txttotamount.Clear();
                    }
                }
            }
            else
            {
                txtqty.Clear();
                txttotamount.Clear();
            }
         
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double tot = Convert.ToDouble(stock) * Convert.ToDouble(txtamo.Text);
            SqlConnection con = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial catalog=pursal;Data Source=SMKG-PC");
            con.Open();            
            String iu = "update inward set qty=" + "'" + stock + "'" + ",perprice=" + "'" + txtamo.Text + "'" + ",amount=" + "'" + tot + "'" + "where qty=" + "'" + lblstock.Text + "'" + " and pid=" + "'" + k + "'";
          SqlCommand  cmd1 = new SqlCommand(iu, con);
            cmd1.ExecuteNonQuery();
            con.Close();

            string k1 = dtp.Value.ToShortDateString();
            dacc.outward_insert(id, txtqty.Text, txttotamount.Text, k1, txtamo.Text, cmb1.Text);
            frmload();
            fill();
            combo();
            clr();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            string s = dataGridView1.Rows[e.RowIndex].Cells[0].Value.ToString();
            SqlDataReader dr;
            dr = dacc.outward_gridclick(s);
            if (dr.HasRows)
            {
                while (dr.Read())
                {
                    txtiid.Text = dr[0].ToString();
                    cmb1.Text = dr[1].ToString();
                    txtqty.Text = dr[2].ToString();
                    txttotamount.Text = dr[3].ToString();
                    dtp.Text = dr[4].ToString();
                }
            }
            else
            {

            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dc.outwarddelete(txtiid.Text);
            fill();
            combo();
            clr();
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

    }
}
