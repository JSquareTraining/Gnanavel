﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;

namespace parking
{
    public partial class vehicleparking : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            lblstatus.Visible = false;
            lblerror.Visible = false;
        }
        protected void Button2_Click(object sender, EventArgs e)
        {
            lblstatus.Visible = true;
            if (txtcontact.Text != "" & txtvnumber.Text != "" & txtname.Text != "" & dttype.Text != "" & ddzone.Text!="")
            {
                string d = DateTime.Now.Date.ToShortDateString();
                string day = DateTime.Now.Day.ToString();
                //string []s1=d.Split('/');
                //string valdate = s1[0] +"."+ s1[1] +"."+ s1[2];
                string valtime = DateTime.Now.Hour.ToString();
              //  valtime = valtime.Remove(2);
                string val = txtname.Text + "," + txtvnumber.Text + "," + txtemail.Text + "," + txtcontact.Text + "," + ddcity.Text + "," + ddzone.Text + "," + d + "," + valtime+","+dttype.Text+","+day;
                string s=txtvnumber.Text+".txt";
                if (File.Exists(@"D:\" + s))
                {
                    clr();
                    lblstatus.Text = "Your Vehicle Already Parked on this Day";
                }
                else
                {
                    File.WriteAllText(@"D:\" + s,val);
                    lblstatus.Text = "Your Vehicle Parked";
                    clr();
                }
            }
        }
        public void clr()
        {
            txtaddress.Text = "";
            txtcontact.Text = "";
            txtemail.Text = "";
            txtname.Text = "";
            txtvnumber.Text = "";
            ddcity.Text = "";
            ddzone.Text = "";
        }
        public int cost, parkinghrs, hr;
        protected void Button1_Click(object sender, EventArgs e)
        {
            if (txtoutvechicle.Text != "")
            {
              string  Path=txtoutvechicle.Text +".txt";
              if (File.Exists(@"D:\" + Path))
              {
                  string s = File.ReadAllText(@"D:\" + Path);
                  string[] s2 = s.Split(',');
                  string parkdate = s2[6];
                  lblin.Text = parkdate;
                  string parktime = s2[7];
                  lblinhr.Text = parktime;
                  string type = s2[8];
                  string outdate = DateTime.Now.Date.ToShortDateString();
                  lbloutda.Text = outdate;
                  string outtime = DateTime.Now.Hour.ToString();
                  lblohr.Text = outtime;
                  string today = DateTime.Now.Day.ToString();
                  string daydiff = (Convert.ToInt32(today) - Convert.ToInt32(s2[9])).ToString();
                  int diff = Convert.ToInt32(daydiff);
                  if (diff != 0)
                  {
                      hr = diff * 12;
                      parkinghrs = hr - (Convert.ToInt32(outtime) - Convert.ToInt32(parktime));
                  }
                  else
                  {
                      parkinghrs = (Convert.ToInt32(outtime) - Convert.ToInt32(parktime));

                  }
                  lbltotalhrs.Text = parkinghrs.ToString();
                  if (type == "Cycle")
                  {
                      cost = parkinghrs * 3;
                      lblhrcost.Text = Convert.ToString(3);
                      if (cost != 0)
                      {
                          lbltotal.Text = cost.ToString();
                      }
                      else
                      {
                          lbltotal.Text = lblhrcost.Text;
                      }

                  }
                  else if (type == "Motor-Bike")
                  {
                      cost = parkinghrs * 5;
                      lblhrcost.Text = Convert.ToString(5);
                      if (cost != 0)
                      {
                          lbltotal.Text = cost.ToString();
                      }
                      else
                      {
                          lbltotal.Text = lblhrcost.Text;
                      }
                  }
                  else if (type == "Four-Wheeler")
                  {
                      cost = parkinghrs * 7;
                      lblhrcost.Text = Convert.ToString(7);
                      if (cost != 0)
                      {
                          lbltotal.Text = cost.ToString();
                      }
                      else
                      {
                          lbltotal.Text = lblhrcost.Text;
                      }
                  }
                  else if (type == "Container")
                  {
                      cost = parkinghrs * 10;
                      lblhrcost.Text = Convert.ToString(10);
                      if (cost != 0)
                      {
                          lbltotal.Text = cost.ToString();
                      }
                      else
                      {
                          lbltotal.Text = lblhrcost.Text;
                      }
                  }
                  else
                  {
                      cost = parkinghrs * 15;
                      lblhrcost.Text = Convert.ToString(15);
                      if (cost != 0)
                      {
                          lbltotal.Text = cost.ToString();
                      }
                      else
                      {
                          lbltotal.Text = lblhrcost.Text;
                      }
                  }
                  File.Delete(@"D:\" + Path);
              }
              else
              {
                  lblerror.Visible = true;
                  lblerror.Text = "This Vehicle Didn't Park";

              }
            }
        }
    }
}